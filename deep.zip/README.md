# 🎰 66Lottery Dashboard

## Files List
```
lottery-dashboard/
├── config.php              ← Site + DB settings (EDIT THIS FIRST)
├── database.sql            ← Run this in phpMyAdmin
├── index.php               ← Home / Dashboard
├── login.php               ← Login page
├── register.php            ← Registration page
├── logout.php              ← Logout
├── wingo.php               ← Win Go game page
├── wallet.php              ← Deposit / Withdraw
├── history.php             ← Bet history
├── referral.php            ← Referral system
├── profile.php             ← User profile
├── includes/
│   ├── header.php          ← Top nav + sidebar
│   ├── footer.php          ← Bottom nav
│   └── auth.php            ← Login/Register functions
├── api/
│   ├── place_bet.php       ← AJAX bet placement
│   ├── latest_results.php  ← AJAX fetch results
│   └── process_draw.php    ← CRON: process draws every 1 min
└── assets/
    ├── css/style.css       ← All styles
    └── js/app.js           ← Frontend JS
```

## Installation Steps

### 1. Upload Files
Upload this entire folder to your hosting (public_html or subfolder).

### 2. Create Database
- Open phpMyAdmin
- Create new database: `lottery_db`
- Import `database.sql`

### 3. Edit config.php
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'lottery_db');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
define('SITE_URL', 'https://yourdomain.com/');
```

### 4. Set Cron Job (for auto draw)
```
* * * * * php /path/to/your/lottery-dashboard/api/process_draw.php
```

### 5. Demo Login
- Email: `admin@66lottery.vip`
- Password: `password`  *(change in phpMyAdmin after first login!)*

## Adding Your Game Link
To embed or link to 66lottery.vip, edit `index.php` and add:
```html
<a href="https://www.66lottery.vip/" target="_blank" class="btn btn--primary">
  Play on 66Lottery
</a>
```

## Requirements
- PHP 7.4+
- MySQL 5.7+ / MariaDB
- Apache / Nginx with mod_rewrite
