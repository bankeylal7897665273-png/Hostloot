<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'Profile - 66Lottery';
$NAV_ACTIVE = 'profile';
$me = me(); $db = db_connect();
$stats = $db->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN status='win' THEN 1 ELSE 0 END) as wins, COALESCE(SUM(amount),0) as wagered FROM bets WHERE user_id=?");
$stats->execute([$_SESSION['uid']]); $stats=$stats->fetch();
include 'includes/header.php';
?>
<!-- PROFILE HERO -->
<div class="profile-hero" style="padding-top:16px;">
  <div class="profile-avatar">👤</div>
  <div class="profile-name"><?= htmlspecialchars($me['username']??'User') ?></div>
  <div class="profile-uid">UID: <?= str_pad($me['id'],8,'0',STR_PAD_LEFT) ?> · 📱 <?= $me['mobile']??$me['email']??'' ?></div>
  <div class="profile-vip">⭐ VIP <?= $me['vip_level'] ?></div>
</div>

<!-- STATS -->
<div class="profile-stats">
  <div class="pstat">
    <div class="pstat-val"><?= money($me['balance']) ?></div>
    <div class="pstat-label">Balance</div>
  </div>
  <div class="pstat">
    <div class="pstat-val"><?= $stats['total'] ?></div>
    <div class="pstat-label">Total Bets</div>
  </div>
  <div class="pstat">
    <div class="pstat-val"><?= $stats['total']>0?round(($stats['wins']/$stats['total'])*100):0 ?>%</div>
    <div class="pstat-label">Win Rate</div>
  </div>
</div>

<div style="height:14px;"></div>

<!-- QUICK ACTIONS -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 12px 16px;">
  <a href="/recharge.php" class="wallet-btn" style="background:linear-gradient(135deg,var(--green),#007a45);">💰 Deposit</a>
  <a href="/withdraw.php" class="wallet-btn" style="background:linear-gradient(135deg,var(--red),#c0340f);">🏦 Withdraw</a>
</div>

<!-- MENU -->
<div class="section">
  <div class="menu-list">
    <a href="/recharge.php" class="menu-item">
      <div class="menu-icon" style="background:rgba(0,185,107,.15);">💰</div>
      <div class="menu-text"><div class="menu-name">Deposit</div><div class="menu-desc">Add funds to your wallet</div></div>
      <div class="menu-arrow">›</div>
    </a>
    <a href="/withdraw.php" class="menu-item">
      <div class="menu-icon" style="background:rgba(240,83,43,.15);">🏦</div>
      <div class="menu-text"><div class="menu-name">Withdraw</div><div class="menu-desc">Transfer to bank/UPI</div></div>
      <div class="menu-arrow">›</div>
    </a>
    <a href="/gift.php" class="menu-item">
      <div class="menu-icon" style="background:rgba(245,197,24,.15);">🎁</div>
      <div class="menu-text"><div class="menu-name">Gift Card</div><div class="menu-desc">Redeem gift card code</div></div>
      <div class="menu-arrow">›</div>
    </a>
    <a href="/invite.php" class="menu-item">
      <div class="menu-icon" style="background:rgba(122,82,201,.15);">👥</div>
      <div class="menu-text"><div class="menu-name">Invite Friends</div><div class="menu-desc">Earn bonus on referrals</div></div>
      <div class="menu-arrow">›</div>
    </a>
    <a href="/history.php" class="menu-item">
      <div class="menu-icon" style="background:rgba(0,176,255,.15);">📋</div>
      <div class="menu-text"><div class="menu-name">Bet History</div><div class="menu-desc">View all your bets</div></div>
      <div class="menu-arrow">›</div>
    </a>
    <a href="/vip.php" class="menu-item">
      <div class="menu-icon" style="background:rgba(245,197,24,.15);">⭐</div>
      <div class="menu-text"><div class="menu-name">VIP Club</div><div class="menu-desc">VIP <?= $me['vip_level'] ?> · Upgrade for more rewards</div></div>
      <div class="menu-arrow">›</div>
    </a>
    <a href="/settings.php" class="menu-item">
      <div class="menu-icon" style="background:rgba(136,153,170,.15);">⚙️</div>
      <div class="menu-text"><div class="menu-name">Settings</div><div class="menu-desc">Change password, profile</div></div>
      <div class="menu-arrow">›</div>
    </a>
    <a href="/logout.php" class="menu-item">
      <div class="menu-icon" style="background:rgba(240,83,43,.1);">🚪</div>
      <div class="menu-text"><div class="menu-name" style="color:var(--red);">Logout</div></div>
      <div class="menu-arrow">›</div>
    </a>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
