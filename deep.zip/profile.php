<?php
define('BASE_PATH', '');
$page_title  = 'Profile';
$active_page = 'profile';
require_once 'config.php';
require_once 'includes/auth.php';
if (!is_logged_in()) redirect('login.php');
$user = get_current_user_data();
$db   = db_connect();
$msg  = ''; $msg_type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = sanitize($_POST['phone'] ?? '');
    $old   = $_POST['old_password'] ?? '';
    $new   = $_POST['new_password'] ?? '';
    $db->prepare("UPDATE users SET phone=? WHERE id=?")->execute([$phone, $user['id']]);
    if ($new) {
        if (!password_verify($old, $user['password'])) { $msg = 'Old password is incorrect.'; $msg_type = 'error'; }
        else { $db->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($new, PASSWORD_BCRYPT), $user['id']]); $msg = 'Password changed!'; }
    } else { $msg = 'Profile updated!'; }
    $user = get_current_user_data();
}

// Stats
$s = $db->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN result='win' THEN 1 ELSE 0 END) as wins, COALESCE(SUM(bet_amount),0) as wagered, COALESCE(SUM(win_amount),0) as won FROM bets WHERE user_id=?");
$s->execute([$user['id']]);
$stats = $s->fetch();
?>
<?php include 'includes/header.php'; ?>

<div class="section-title mb-4">My <span>Profile</span></div>

<!-- Profile Card -->
<div class="card mb-6" style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;">
  <div style="width:72px;height:72px;background:linear-gradient(135deg,var(--purple),var(--purple-lt));border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:30px;flex-shrink:0;">👤</div>
  <div>
    <div style="font-family:'Rajdhani',sans-serif;font-size:24px;font-weight:700;"><?= htmlspecialchars($user['username']) ?></div>
    <div style="color:#6b6b8f;font-size:13px;"><?= htmlspecialchars($user['email']) ?></div>
    <div style="margin-top:6px;"><span class="badge badge-win" style="font-size:11px;">● Active</span></div>
  </div>
  <div style="margin-left:auto;text-align:right;">
    <div style="font-size:11px;color:#6b6b8f;">Member since</div>
    <div style="font-size:13px;font-weight:600;"><?= date('d M Y', strtotime($user['created_at'])) ?></div>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid mb-6">
  <div class="stat-card purple">
    <div class="stat-card__icon">🎲</div>
    <div class="stat-card__val"><?= $stats['total'] ?></div>
    <div class="stat-card__lbl">Total Bets</div>
  </div>
  <div class="stat-card green">
    <div class="stat-card__icon">🏆</div>
    <div class="stat-card__val"><?= $stats['wins'] ?></div>
    <div class="stat-card__lbl">Total Wins</div>
  </div>
  <div class="stat-card gold">
    <div class="stat-card__icon">💰</div>
    <div class="stat-card__val"><?= CURRENCY . number_format($stats['wagered'], 0) ?></div>
    <div class="stat-card__lbl">Wagered</div>
  </div>
  <div class="stat-card red">
    <div class="stat-card__icon">🎯</div>
    <div class="stat-card__val"><?= $stats['total'] > 0 ? round(($stats['wins']/$stats['total'])*100) : 0 ?>%</div>
    <div class="stat-card__lbl">Win Rate</div>
  </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-<?= $msg_type ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<!-- Edit Form -->
<div class="card">
  <div class="card__title">Edit Profile</div>
  <form method="POST">
    <div class="form-group">
      <label>Username</label>
      <input type="text" value="<?= htmlspecialchars($user['username']) ?>" disabled style="opacity:.5;cursor:not-allowed;"/>
    </div>
    <div class="form-group">
      <label>Email</label>
      <input type="email" value="<?= htmlspecialchars($user['email']) ?>" disabled style="opacity:.5;cursor:not-allowed;"/>
    </div>
    <div class="form-group">
      <label>Phone</label>
      <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="+91 XXXXXXXXXX"/>
    </div>
    <div class="card__title mt-6">Change Password</div>
    <div class="form-group">
      <label>Old Password</label>
      <input type="password" name="old_password" placeholder="Enter current password"/>
    </div>
    <div class="form-group">
      <label>New Password</label>
      <input type="password" name="new_password" placeholder="Min 6 characters"/>
    </div>
    <button type="submit" class="btn btn--primary btn--full btn--lg"><i class="fa fa-save"></i> Save Changes</button>
  </form>
  <div style="margin-top:20px;padding-top:20px;border-top:1px solid var(--border);">
    <div style="font-size:12px;color:#6b6b8f;margin-bottom:6px;">YOUR REFERRAL CODE</div>
    <div style="font-family:'Rajdhani',sans-serif;font-size:24px;font-weight:700;color:var(--gold);letter-spacing:3px;"><?= $user['referral_code'] ?? 'N/A' ?></div>
    <a href="referral.php" class="btn btn--outline" style="margin-top:10px;font-size:13px;"><i class="fa fa-users"></i> Share & Earn</a>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
