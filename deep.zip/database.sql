-- ============================================================
--  66LOTTERY DATABASE SETUP
--  Run this SQL in phpMyAdmin or MySQL CLI
-- ============================================================

CREATE DATABASE IF NOT EXISTS lottery_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lottery_db;

-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50)  NOT NULL UNIQUE,
    email         VARCHAR(100) NOT NULL UNIQUE,
    phone         VARCHAR(15),
    password      VARCHAR(255) NOT NULL,
    balance       DECIMAL(12,2) DEFAULT 0.00,
    total_won     DECIMAL(12,2) DEFAULT 0.00,
    total_played  INT DEFAULT 0,
    avatar        VARCHAR(255) DEFAULT 'assets/img/default-avatar.png',
    referral_code VARCHAR(20),
    referred_by   INT DEFAULT NULL,
    status        ENUM('active','banned','pending') DEFAULT 'active',
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login    DATETIME
);

-- GAMES TABLE
CREATE TABLE IF NOT EXISTS games (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    slug        VARCHAR(100) NOT NULL UNIQUE,
    category    VARCHAR(50),
    description TEXT,
    image       VARCHAR(255),
    min_bet     DECIMAL(10,2) DEFAULT 10.00,
    max_bet     DECIMAL(10,2) DEFAULT 10000.00,
    rtp         DECIMAL(5,2)  DEFAULT 95.00,  -- Return to Player %
    is_active   TINYINT(1)    DEFAULT 1,
    is_featured TINYINT(1)    DEFAULT 0,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- BETS / TRANSACTIONS TABLE
CREATE TABLE IF NOT EXISTS bets (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    game_id     INT NOT NULL,
    bet_amount  DECIMAL(12,2) NOT NULL,
    win_amount  DECIMAL(12,2) DEFAULT 0.00,
    result      ENUM('win','loss','pending') DEFAULT 'pending',
    bet_data    JSON,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (game_id) REFERENCES games(id)
);

-- DEPOSITS TABLE
CREATE TABLE IF NOT EXISTS deposits (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    amount     DECIMAL(12,2) NOT NULL,
    method     VARCHAR(50),
    txn_id     VARCHAR(100),
    status     ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- WITHDRAWALS TABLE
CREATE TABLE IF NOT EXISTS withdrawals (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    amount     DECIMAL(12,2) NOT NULL,
    method     VARCHAR(50),
    account    VARCHAR(200),
    status     ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- LOTTERY DRAWS TABLE
CREATE TABLE IF NOT EXISTS lottery_draws (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    draw_type   VARCHAR(50) NOT NULL,  -- 'wingo','k3','5d'
    period      VARCHAR(30) NOT NULL,
    result      VARCHAR(20),
    big_small   VARCHAR(10),
    odd_even    VARCHAR(10),
    color       VARCHAR(20),
    status      ENUM('pending','complete') DEFAULT 'pending',
    draw_time   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS notifications (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT,           -- NULL = global
    title      VARCHAR(200),
    message    TEXT,
    type       VARCHAR(30) DEFAULT 'info',
    is_read    TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- SEED: Demo Games
-- ============================================================
INSERT INTO games (name, slug, category, description, min_bet, max_bet, rtp, is_featured) VALUES
('Win Go 1Min',  'wingo-1min',  'lottery', 'Predict color, number every 1 minute',  10, 10000, 95, 1),
('Win Go 3Min',  'wingo-3min',  'lottery', 'Predict color, number every 3 minutes', 10, 10000, 95, 1),
('Win Go 5Min',  'wingo-5min',  'lottery', 'Predict color, number every 5 minutes', 10, 10000, 95, 0),
('K3 Lotre',     'k3-lotre',    'dice',    '3 dice lottery game',                   10, 5000,  94, 1),
('5D Lotre',     '5d-lotre',    'lottery', '5 digit lottery prediction',             10, 5000,  94, 0),
('Trx Win Go',   'trx-wingo',   'crypto',  'TRX blockchain lottery',                10, 20000, 95, 1);

-- Demo admin user (password: admin123)
INSERT INTO users (username, email, password, balance, status) VALUES
('admin', 'admin@66lottery.vip', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 50000.00, 'active');
