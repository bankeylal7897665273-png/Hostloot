CREATE DATABASE IF NOT EXISTS lottery_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lottery_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  mobile VARCHAR(15) UNIQUE,
  email VARCHAR(100) UNIQUE,
  username VARCHAR(50),
  password VARCHAR(255) NOT NULL,
  balance DECIMAL(14,2) DEFAULT 0.00,
  total_deposit DECIMAL(14,2) DEFAULT 0.00,
  total_withdraw DECIMAL(14,2) DEFAULT 0.00,
  total_won DECIMAL(14,2) DEFAULT 0.00,
  referral_code VARCHAR(12) UNIQUE,
  referred_by INT DEFAULT NULL,
  vip_level INT DEFAULT 0,
  avatar VARCHAR(255) DEFAULT '',
  status ENUM('active','banned') DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_login DATETIME
);

CREATE TABLE IF NOT EXISTS wingo_periods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  period_no VARCHAR(20) UNIQUE,
  game_type ENUM('1min','3min','5min','10min') DEFAULT '1min',
  result_num TINYINT,
  result_color VARCHAR(10),
  result_size VARCHAR(5),
  status ENUM('open','closed') DEFAULT 'open',
  open_time DATETIME,
  close_time DATETIME
);

CREATE TABLE IF NOT EXISTS k3_periods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  period_no VARCHAR(20) UNIQUE,
  game_type ENUM('1min','3min','5min','10min') DEFAULT '1min',
  dice1 TINYINT, dice2 TINYINT, dice3 TINYINT,
  total INT,
  result_size VARCHAR(5),
  result_parity VARCHAR(5),
  status ENUM('open','closed') DEFAULT 'open',
  open_time DATETIME,
  close_time DATETIME
);

CREATE TABLE IF NOT EXISTS bets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  game VARCHAR(20),
  period_no VARCHAR(20),
  bet_type VARCHAR(30),
  bet_value VARCHAR(30),
  amount DECIMAL(12,2),
  fee DECIMAL(10,2) DEFAULT 0,
  win_amount DECIMAL(12,2) DEFAULT 0,
  status ENUM('pending','win','loss') DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS deposits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  amount DECIMAL(12,2),
  method VARCHAR(30),
  utr VARCHAR(50),
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS withdrawals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  amount DECIMAL(12,2),
  method VARCHAR(30),
  account_info VARCHAR(255),
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS gift_cards (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(30) UNIQUE,
  amount DECIMAL(10,2),
  used_by INT DEFAULT NULL,
  used_at DATETIME DEFAULT NULL,
  status ENUM('active','used') DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS notices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  content TEXT,
  is_active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Demo data
INSERT IGNORE INTO users (mobile,email,username,password,balance,referral_code,vip_level) VALUES
('9999999999','admin@66lottery.vip','Admin','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',50000.00,'ADM00001',5);

INSERT IGNORE INTO gift_cards (code,amount) VALUES
('GIFT100FREE',100.00),('LUCKY500WIN',500.00),('NEW200JOIN',200.00);

INSERT IGNORE INTO notices (content) VALUES
('🎉 Welcome to 66Lottery! Fastest withdrawal in 1 minute! Register now and get bonus!');

-- Seed wingo periods
INSERT IGNORE INTO wingo_periods (period_no,game_type,result_num,result_color,result_size,status,open_time,close_time) VALUES
(CONCAT(DATE_FORMAT(NOW(),'%Y%m%d%H'),LPAD(FLOOR(MINUTE(NOW())/1)*1,2,'0'),'001'),'1min',5,'green','big','open',NOW(),DATE_ADD(NOW(),INTERVAL 1 MINUTE));
