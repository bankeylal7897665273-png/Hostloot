<?php
require_once __DIR__ . '/../config.php';

// ============================================================
//  REGISTER USER
// ============================================================
function register_user($username, $email, $phone, $password, $referral = null) {
    $db   = db_connect();
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $ref_code = strtoupper(substr(md5($username . time()), 0, 8));

    $referred_by = null;
    if ($referral) {
        $stmt = $db->prepare("SELECT id FROM users WHERE referral_code = ?");
        $stmt->execute([$referral]);
        $ref_user = $stmt->fetch();
        if ($ref_user) $referred_by = $ref_user['id'];
    }

    try {
        $stmt = $db->prepare("INSERT INTO users (username, email, phone, password, referral_code, referred_by) VALUES (?,?,?,?,?,?)");
        $stmt->execute([$username, $email, $phone, $hash, $ref_code, $referred_by]);
        return ['success' => true, 'user_id' => $db->lastInsertId()];
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            return ['success' => false, 'error' => 'Username or email already exists.'];
        }
        return ['success' => false, 'error' => 'Registration failed.'];
    }
}

// ============================================================
//  LOGIN USER
// ============================================================
function login_user($login, $password) {
    $db   = db_connect();
    $stmt = $db->prepare("SELECT * FROM users WHERE (email=? OR username=?) AND status='active' LIMIT 1");
    $stmt->execute([$login, $login]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['balance']  = $user['balance'];

        // Update last login
        $db->prepare("UPDATE users SET last_login=NOW() WHERE id=?")->execute([$user['id']]);
        return ['success' => true];
    }
    return ['success' => false, 'error' => 'Invalid credentials.'];
}

// ============================================================
//  GET CURRENT USER
// ============================================================
function get_current_user_data() {
    if (!is_logged_in()) return null;
    $db   = db_connect();
    $stmt = $db->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

// ============================================================
//  LOGOUT
// ============================================================
function logout_user() {
    session_destroy();
    redirect('../index.php');
}
?>
