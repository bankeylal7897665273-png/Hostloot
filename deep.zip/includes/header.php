<?php
if(!defined('IN_APP')) { header('Location:/index.php'); exit; }
$__me = me();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
<meta name="theme-color" content="#00b96b"/>
<title><?= htmlspecialchars($PAGE_TITLE ?? SITE_NAME) ?></title>
<link rel="stylesheet" href="/css/style.css"/>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
<div id="toast" class="toast"></div>
<?php if (!($HIDE_TOPBAR ?? false)): ?>
<div class="topbar">
  <div class="topbar-logo">66<span>Lottery</span></div>
  <div class="topbar-right">
    <?php if ($__me): ?>
    <div class="topbar-user">
      <div style="font-size:11px;color:rgba(255,255,255,.75);">Balance</div>
      <div class="balance-val" style="font-size:13px;font-weight:700;"><?= money($__me['balance']) ?></div>
    </div>
    <a href="/profile.php" class="topbar-icon">👤</a>
    <?php else: ?>
    <a href="/login.php" style="background:rgba(255,255,255,.2);color:#fff;padding:6px 14px;border-radius:99px;font-size:12px;font-weight:700;">Login</a>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>
<div class="page-wrap">
