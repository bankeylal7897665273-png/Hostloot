<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/auth.php';
$user = get_current_user_data();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <meta name="theme-color" content="#0d0d1a"/>
  <title><?= SITE_NAME ?> – <?= $page_title ?? 'Dashboard' ?></title>
  <link rel="stylesheet" href="<?= BASE_PATH ?? '' ?>assets/css/style.css"/>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>

<!-- TOP NAV -->
<nav class="topnav">
  <div class="topnav__brand">
    <span class="logo-icon">🎰</span>
    <span class="logo-text"><?= SITE_NAME ?></span>
  </div>
  <div class="topnav__right">
    <?php if ($user): ?>
      <div class="balance-chip">
        <i class="fa fa-wallet"></i>
        <span><?= format_currency($user['balance']) ?></span>
      </div>
      <div class="topnav__avatar" onclick="toggleDropdown()">
        <i class="fa fa-user-circle fa-lg"></i>
        <span><?= htmlspecialchars($user['username']) ?></span>
        <i class="fa fa-chevron-down fa-xs"></i>
      </div>
      <div class="user-dropdown" id="userDropdown">
        <a href="profile.php"><i class="fa fa-user"></i> Profile</a>
        <a href="wallet.php"><i class="fa fa-wallet"></i> Wallet</a>
        <a href="history.php"><i class="fa fa-history"></i> History</a>
        <hr/>
        <a href="logout.php" class="logout-link"><i class="fa fa-sign-out-alt"></i> Logout</a>
      </div>
    <?php else: ?>
      <a href="login.php" class="btn btn--outline">Login</a>
      <a href="register.php" class="btn btn--primary">Register</a>
    <?php endif; ?>
  </div>
</nav>

<!-- SIDEBAR -->
<div class="layout">
<aside class="sidebar" id="sidebar">
  <ul class="sidebar__menu">
    <li><a href="index.php" class="<?= ($active_page??'') == 'home' ? 'active' : '' ?>"><i class="fa fa-home"></i><span>Home</span></a></li>
    <li class="menu-label">Games</li>
    <li><a href="wingo.php" class="<?= ($active_page??'') == 'wingo' ? 'active' : '' ?>"><i class="fa fa-circle"></i><span>Win Go</span></a></li>
    <li><a href="k3.php"    class="<?= ($active_page??'') == 'k3' ? 'active' : '' ?>"><i class="fa fa-dice"></i><span>K3 Lotre</span></a></li>
    <li><a href="5d.php"    class="<?= ($active_page??'') == '5d' ? 'active' : '' ?>"><i class="fa fa-hashtag"></i><span>5D Lotre</span></a></li>
    <li><a href="trx.php"   class="<?= ($active_page??'') == 'trx' ? 'active' : '' ?>"><i class="fa fa-coins"></i><span>Trx Win Go</span></a></li>
    <li class="menu-label">Account</li>
    <li><a href="wallet.php"   class="<?= ($active_page??'') == 'wallet' ? 'active' : '' ?>"><i class="fa fa-wallet"></i><span>Wallet</span></a></li>
    <li><a href="history.php"  class="<?= ($active_page??'') == 'history' ? 'active' : '' ?>"><i class="fa fa-history"></i><span>Bet History</span></a></li>
    <li><a href="referral.php" class="<?= ($active_page??'') == 'referral' ? 'active' : '' ?>"><i class="fa fa-users"></i><span>Referral</span></a></li>
    <li><a href="profile.php"  class="<?= ($active_page??'') == 'profile' ? 'active' : '' ?>"><i class="fa fa-user-cog"></i><span>Profile</span></a></li>
  </ul>
</aside>
<main class="main-content">
