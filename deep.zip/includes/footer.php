</main>
</div><!-- .layout -->

<!-- BOTTOM NAV (mobile) -->
<nav class="bottomnav">
  <a href="index.php"   class="<?= ($active_page??'') == 'home'    ? 'active' : '' ?>"><i class="fa fa-home"></i><span>Home</span></a>
  <a href="wingo.php"   class="<?= ($active_page??'') == 'wingo'   ? 'active' : '' ?>"><i class="fa fa-circle"></i><span>Win Go</span></a>
  <a href="wallet.php"  class="<?= ($active_page??'') == 'wallet'  ? 'active' : '' ?>"><i class="fa fa-wallet"></i><span>Wallet</span></a>
  <a href="history.php" class="<?= ($active_page??'') == 'history' ? 'active' : '' ?>"><i class="fa fa-history"></i><span>History</span></a>
  <a href="profile.php" class="<?= ($active_page??'') == 'profile' ? 'active' : '' ?>"><i class="fa fa-user"></i><span>Profile</span></a>
</nav>

<script src="assets/js/app.js"></script>
</body>
</html>
