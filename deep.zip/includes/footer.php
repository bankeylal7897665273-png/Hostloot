</div><!-- page-wrap -->

<?php if (!($HIDE_NAV ?? false)): ?>
<nav class="bottom-nav">
  <a href="/index.php" class="bnav-item <?= ($NAV_ACTIVE??'')==='home'?'active':'' ?>">
    <div class="bnav-icon"><i class="fa fa-home"></i></div>
    <div class="bnav-label">Home</div>
  </a>
  <a href="/activity.php" class="bnav-item <?= ($NAV_ACTIVE??'')==='activity'?'active':'' ?>">
    <div class="bnav-icon"><i class="fa fa-trophy"></i></div>
    <div class="bnav-label">Activity</div>
  </a>
  <a href="/recharge.php" class="bnav-item <?= ($NAV_ACTIVE??'')==='recharge'?'active':'' ?>" style="position:relative;top:-10px">
    <div style="width:52px;height:52px;background:linear-gradient(135deg,#00b96b,#007a45);border-radius:50%;display:flex;align-items:center;justify-content:center;border:3px solid #0f1923;">
      <i class="fa fa-wallet" style="color:#fff;font-size:20px;"></i>
    </div>
    <div class="bnav-label" style="margin-top:-4px;">Recharge</div>
  </a>
  <a href="/invite.php" class="bnav-item <?= ($NAV_ACTIVE??'')==='invite'?'active':'' ?>">
    <div class="bnav-icon"><i class="fa fa-users"></i></div>
    <div class="bnav-label">Invite</div>
  </a>
  <a href="/profile.php" class="bnav-item <?= ($NAV_ACTIVE??'')==='profile'?'active':'' ?>">
    <div class="bnav-icon"><i class="fa fa-user-circle"></i></div>
    <div class="bnav-label">Me</div>
  </a>
</nav>
<?php endif; ?>

<script src="/js/app.js"></script>
<?php if (!empty($EXTRA_JS)) echo $EXTRA_JS; ?>
</body>
</html>
