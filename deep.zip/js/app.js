// ── TOAST ──────────────────────────────────────────────────
function toast(msg, type='success') {
  let el = document.getElementById('toast');
  if (!el) { el = document.createElement('div'); el.id='toast'; el.className='toast'; document.body.appendChild(el); }
  el.textContent = msg;
  el.className = 'toast ' + (type==='error'?'error':'') + ' show';
  setTimeout(() => el.classList.remove('show'), 2600);
}

// ── MODAL ──────────────────────────────────────────────────
function openModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('show');
  }
});

// ── BET MODAL OPEN ─────────────────────────────────────────
let currentBet = { type:'', value:'', label:'', color:'', amount:10 };

function openBetModal(type, value, label, ballClass) {
  currentBet = { type, value, label, ballClass, amount: 10 };
  document.getElementById('selBall').className = 'rball sel-ball ' + ballClass;
  document.getElementById('selBall').textContent = type === 'number' ? value : '';
  document.getElementById('selLabel').textContent = label;
  document.getElementById('betAmountInp').value = 10;
  updateModalInfo();
  openModal('betModal');
}

function updateModalInfo() {
  const amt = parseFloat(document.getElementById('betAmountInp').value) || 0;
  const fee = +(amt * 0.02).toFixed(2);
  const after = +(amt - fee).toFixed(2);
  document.getElementById('infoAmt').textContent = '₹' + amt.toFixed(2);
  document.getElementById('infoFee').textContent = '₹' + fee.toFixed(2);
  document.getElementById('infoAfter').textContent = '₹' + after.toFixed(2);
  currentBet.amount = amt;
}

document.addEventListener('input', e => {
  if (e.target.id === 'betAmountInp') {
    updateModalInfo();
    document.querySelectorAll('.amt-btn').forEach(b => b.classList.remove('active'));
  }
});

document.addEventListener('click', e => {
  if (e.target.classList.contains('amt-btn')) {
    const v = e.target.dataset.val;
    if (v === 'x5') {
      document.getElementById('betAmountInp').value = (currentBet.amount || 10) * 5;
    } else if (v === 'x10') {
      document.getElementById('betAmountInp').value = (currentBet.amount || 10) * 10;
    } else {
      document.getElementById('betAmountInp').value = v;
    }
    document.querySelectorAll('.amt-btn').forEach(b => b.classList.remove('active'));
    e.target.classList.add('active');
    updateModalInfo();
  }
});

// ── PLACE BET ──────────────────────────────────────────────
function placeBet(game) {
  const amt = parseFloat(document.getElementById('betAmountInp').value);
  if (!amt || amt < 10) { toast('Minimum bet is ₹10', 'error'); return; }
  if (!currentBet.value) { toast('Please select a bet option', 'error'); return; }
  const body = { game, type: currentBet.type, value: currentBet.value, amount: amt };
  fetch('/api/place_bet.php', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify(body)
  }).then(r=>r.json()).then(d=>{
    closeModal('betModal');
    if (d.success) {
      toast('✅ Bet placed! ₹' + amt.toFixed(2));
      document.querySelectorAll('.balance-val').forEach(el => el.textContent = '₹' + parseFloat(d.balance).toFixed(2));
    } else {
      toast(d.error || 'Failed', 'error');
    }
  }).catch(()=>toast('Network error','error'));
}

// ── COUNTDOWN TIMER ────────────────────────────────────────
function startTimer(secs, elId, onDone) {
  let s = secs;
  const el = document.getElementById(elId);
  if (!el) return;
  const tick = () => {
    if (s < 0) { if (onDone) onDone(); return; }
    const m = String(Math.floor(s/60)).padStart(2,'0');
    const sec = String(s%60).padStart(2,'0');
    el.textContent = m + ':' + sec;
    if (s === 10) el.style.color = '#f0532b';
    s--;
    setTimeout(tick, 1000);
  };
  tick();
}

// ── COPY TEXT ──────────────────────────────────────────────
function copyText(txt) {
  navigator.clipboard.writeText(txt).then(()=>toast('✅ Copied!')).catch(()=>{
    const ta = document.createElement('textarea');
    ta.value = txt; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); document.body.removeChild(ta);
    toast('✅ Copied!');
  });
}

// ── TABS SWITCH ────────────────────────────────────────────
function switchTab(id, tabs, contents) {
  document.querySelectorAll(tabs).forEach(t=>t.classList.remove('active'));
  document.querySelectorAll(contents).forEach(c=>c.style.display='none');
  document.getElementById(id+'Tab').classList.add('active');
  document.getElementById(id+'Content').style.display='block';
}

// ── AMOUNT GRID ────────────────────────────────────────────
document.addEventListener('click', e => {
  if (e.target.classList.contains('agrid-btn')) {
    document.querySelectorAll('.agrid-btn').forEach(b=>b.classList.remove('active'));
    e.target.classList.add('active');
    const inp = document.querySelector('.amount-main-inp');
    if (inp) inp.value = e.target.dataset.val;
  }
  if (e.target.classList.contains('rmethod')) {
    document.querySelectorAll('.rmethod').forEach(b=>b.classList.remove('active'));
    e.target.classList.add('active');
  }
  if (e.target.classList.contains('page-tab')) {
    const target = e.target.dataset.target;
    if (!target) return;
    document.querySelectorAll('.page-tab').forEach(b=>b.classList.remove('active'));
    e.target.classList.add('active');
    document.querySelectorAll('.tab-content').forEach(c=>c.style.display='none');
    const tc = document.getElementById(target);
    if (tc) tc.style.display='block';
  }
});
