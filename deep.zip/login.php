<?php
require_once 'config.php';
require_once 'includes/auth.php';
if (is_logged_in()) redirect('index.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login    = sanitize($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    if (!$login || !$password) {
        $error = 'All fields are required.';
    } else {
        $result = login_user($login, $password);
        if ($result['success']) redirect('index.php');
        else $error = $result['error'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title><?= SITE_NAME ?> – Login</title>
  <link rel="stylesheet" href="assets/css/style.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
<div class="auth-wrap">
  <div class="auth-box">
    <div class="auth-logo">
      <span class="logo-icon">🎰</span>
      <span class="logo-text"><?= SITE_NAME ?></span>
      <p style="color:#6b6b8f;font-size:12px;margin-top:4px;"><?= SITE_TAGLINE ?></p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error"><i class="fa fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label>Email / Username</label>
        <input type="text" name="login" placeholder="Enter your email or username" required/>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Enter your password" required/>
      </div>
      <button type="submit" class="btn btn--primary btn--full btn--lg" style="margin-top:8px;">
        <i class="fa fa-sign-in-alt"></i> Login
      </button>
    </form>
    <div class="auth-footer">
      Don't have an account? <a href="register.php">Register now</a>
    </div>
  </div>
</div>
</body>
</html>
