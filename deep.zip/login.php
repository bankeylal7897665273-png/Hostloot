<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
if (is_logged_in()) go('/index.php');
$PAGE_TITLE = 'Login - 66Lottery';
$HIDE_TOPBAR = true;
$HIDE_NAV = true;

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $mobile = preg_replace('/\D/','',$_POST['mobile'] ?? '');
    $pass   = $_POST['password'] ?? '';

    if ($action === 'login') {
        if (!$mobile || !$pass) { $err = 'Please fill all fields.'; }
        else {
            $db = db_connect();
            $s  = $db->prepare("SELECT * FROM users WHERE mobile=? AND status='active' LIMIT 1");
            $s->execute([$mobile]);
            $u = $s->fetch();
            if ($u && password_verify($pass, $u['password'])) {
                $_SESSION['uid'] = $u['id'];
                $_SESSION['uname'] = $u['username'];
                $db->prepare("UPDATE users SET last_login=NOW() WHERE id=?")->execute([$u['id']]);
                go('/index.php');
            } else { $err = '❌ Invalid mobile or password.'; }
        }
    } elseif ($action === 'register') {
        $name  = clean($_POST['username'] ?? '');
        $ref   = clean($_POST['ref'] ?? '');
        $pass2 = $_POST['password2'] ?? '';
        if (!$mobile || !$pass || !$name) { $err = 'Please fill all fields.'; }
        elseif (strlen($pass) < 6) { $err = 'Password must be 6+ characters.'; }
        elseif ($pass !== $pass2) { $err = 'Passwords do not match.'; }
        else {
            $db = db_connect();
            $code = strtoupper(substr(md5($mobile.time()),0,8));
            $ref_id = null;
            if ($ref) {
                $r = $db->prepare("SELECT id FROM users WHERE referral_code=?");
                $r->execute([$ref]); $rf = $r->fetch();
                if ($rf) $ref_id = $rf['id'];
            }
            try {
                $db->prepare("INSERT INTO users(mobile,username,password,referral_code,referred_by) VALUES(?,?,?,?,?)")
                   ->execute([$mobile,$name,password_hash($pass,PASSWORD_BCRYPT),$code,$ref_id]);
                $uid = $db->lastInsertId();
                $_SESSION['uid'] = $uid;
                $_SESSION['uname'] = $name;
                go('/index.php');
            } catch(PDOException $e) {
                $err = '❌ Mobile number already registered.';
            }
        }
    }
}
include 'includes/header.php';
?>
<div class="auth-bg">
  <div class="auth-top">
    <div class="auth-logo-big">66<span>Lottery</span></div>
    <div class="auth-sub">🎰 India's Most Trusted Lottery</div>
    <div style="display:flex;gap:12px;justify-content:center;margin-top:16px;font-size:12px;color:rgba(255,255,255,.8);">
      <span>✅ Fast Withdrawal</span>
      <span>✅ 100% Safe</span>
      <span>✅ 24/7 Support</span>
    </div>
  </div>
  <div class="auth-card">
    <div class="auth-tabs">
      <div class="auth-tab active" id="loginTab" onclick="switchAuthTab('login')">Login</div>
      <div class="auth-tab" id="registerTab" onclick="switchAuthTab('register')">Register</div>
    </div>

    <?php if ($err): ?>
    <div style="background:rgba(240,83,43,.15);border:1px solid rgba(240,83,43,.3);color:#ff7b5e;padding:10px 14px;border-radius:10px;font-size:13px;margin-bottom:14px;"><?= $err ?></div>
    <?php endif; ?>

    <!-- LOGIN FORM -->
    <div id="loginForm">
      <form method="POST">
        <input type="hidden" name="action" value="login"/>
        <div class="form-group">
          <label class="form-label">📱 Mobile Number</label>
          <div class="phone-row">
            <div class="flag-box">🇮🇳 +91</div>
            <input class="form-input" type="tel" name="mobile" placeholder="Enter mobile number" maxlength="10" required/>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">🔒 Password</label>
          <input class="form-input" type="password" name="password" placeholder="Enter password" required/>
        </div>
        <div style="text-align:right;margin-bottom:16px;">
          <a href="#" style="font-size:12px;color:var(--green);">Forgot Password?</a>
        </div>
        <button type="submit" class="submit-btn">Login →</button>
      </form>
    </div>

    <!-- REGISTER FORM -->
    <div id="registerForm" style="display:none;">
      <form method="POST">
        <input type="hidden" name="action" value="register"/>
        <div class="form-group">
          <label class="form-label">👤 Username</label>
          <input class="form-input" type="text" name="username" placeholder="Enter username" required/>
        </div>
        <div class="form-group">
          <label class="form-label">📱 Mobile Number</label>
          <div class="phone-row">
            <div class="flag-box">🇮🇳 +91</div>
            <input class="form-input" type="tel" name="mobile" placeholder="Enter mobile number" maxlength="10" required/>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">🔒 Password</label>
          <input class="form-input" type="password" name="password" placeholder="Min 6 characters" required/>
        </div>
        <div class="form-group">
          <label class="form-label">🔒 Confirm Password</label>
          <input class="form-input" type="password" name="password2" placeholder="Repeat password" required/>
        </div>
        <div class="form-group">
          <label class="form-label">🎫 Referral Code (optional)</label>
          <input class="form-input" type="text" name="ref" placeholder="Enter referral code" value="<?= clean($_GET['ref'] ?? '') ?>"/>
        </div>
        <button type="submit" class="submit-btn">Create Account 🎉</button>
      </form>
    </div>
  </div>
</div>

<script>
function switchAuthTab(t) {
  document.getElementById('loginTab').classList.toggle('active', t==='login');
  document.getElementById('registerTab').classList.toggle('active', t==='register');
  document.getElementById('loginForm').style.display = t==='login'?'block':'none';
  document.getElementById('registerForm').style.display = t==='register'?'block':'none';
}
</script>
<?php include 'includes/footer.php'; ?>
