<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'Recharge - 66Lottery';
$NAV_ACTIVE = 'recharge';
$me = me();
$db = db_connect();
$msg=''; $msg_type='success';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $amount = floatval($_POST['amount']??0);
    $method = clean($_POST['method']??'');
    $utr    = clean($_POST['utr']??'');
    if ($amount < 100) { $msg='Minimum deposit is ₹100.'; $msg_type='error'; }
    elseif (!$method)  { $msg='Please select payment method.'; $msg_type='error'; }
    else {
        $db->prepare("INSERT INTO deposits(user_id,amount,method,utr) VALUES(?,?,?,?)")
           ->execute([$_SESSION['uid'],$amount,$method,$utr]);
        $msg='✅ Deposit request submitted! We will verify and add funds within 10 minutes.';
    }
}
$deps = $db->prepare("SELECT * FROM deposits WHERE user_id=? ORDER BY id DESC LIMIT 10");
$deps->execute([$_SESSION['uid']]); $deps=$deps->fetchAll();
include 'includes/header.php';
?>

<div class="wingo-header">
  <div style="display:flex;align-items:center;gap:12px;">
    <a href="/index.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">Recharge</div>
  </div>
</div>

<!-- BALANCE CARD -->
<div class="wallet-card">
  <div class="wallet-label">Available Balance</div>
  <div class="wallet-amount"><?= money($me['balance']) ?></div>
  <div style="font-size:12px;color:rgba(255,255,255,.7);">Total Deposited: <?= money($me['total_deposit']) ?></div>
</div>

<!-- PAGE TABS -->
<div style="display:flex;padding:0 12px 12px;gap:6px;">
  <div class="page-tab active" id="depositTabBtn" onclick="showRechargeTab('deposit')">Deposit</div>
  <div class="page-tab" id="historyTabBtn" onclick="showRechargeTab('history')">History</div>
</div>

<!-- DEPOSIT FORM -->
<div id="depositTab">
  <?php if ($msg): ?>
  <div style="margin:0 12px 12px;padding:12px;border-radius:10px;font-size:13px;background:rgba(<?= $msg_type==='error'?'240,83,43':'0,185,107' ?>,.12);border:1px solid rgba(<?= $msg_type==='error'?'240,83,43':'0,185,107' ?>,.3);color:<?= $msg_type==='error'?'var(--red)':'var(--green)' ?>;"><?= $msg ?></div>
  <?php endif; ?>

  <div class="section">
    <form method="POST">
      <div class="form-group">
        <label class="form-label">💳 Select Payment Method</label>
        <div class="recharge-methods">
          <div class="rmethod active" onclick="selMethod(this,'upi')">
            <div class="rmethod-icon">📱</div>
            <div class="rmethod-name">UPI</div>
            <input type="radio" name="method" value="upi" checked style="display:none;"/>
          </div>
          <div class="rmethod" onclick="selMethod(this,'netbanking')">
            <div class="rmethod-icon">🏦</div>
            <div class="rmethod-name">Net Bank</div>
            <input type="radio" name="method" value="netbanking" style="display:none;"/>
          </div>
          <div class="rmethod" onclick="selMethod(this,'crypto')">
            <div class="rmethod-icon">💎</div>
            <div class="rmethod-name">Crypto</div>
            <input type="radio" name="method" value="crypto" style="display:none;"/>
          </div>
        </div>
      </div>

      <!-- UPI QR -->
      <div id="upiBox" class="section" style="background:var(--card);border:1px solid var(--border);border-radius:12px;padding:16px;text-align:center;margin-bottom:14px;">
        <div style="font-size:12px;color:var(--muted);margin-bottom:8px;">Scan & Pay UPI</div>
        <div style="background:#fff;width:140px;height:140px;margin:0 auto 10px;border-radius:10px;display:flex;align-items:center;justify-content:center;">
          <div style="color:#000;font-size:11px;padding:8px;">QR Code<br/>Here<br/>(Add your UPI QR)</div>
        </div>
        <div style="font-size:13px;font-weight:700;color:var(--green);">lottery66pay@upi</div>
        <div onclick="copyText('lottery66pay@upi')" style="margin-top:8px;font-size:12px;color:var(--muted);cursor:pointer;">📋 Tap to copy UPI ID</div>
      </div>

      <div class="form-group">
        <label class="form-label">💰 Deposit Amount</label>
        <div class="amount-grid">
          <?php foreach([100,200,500,1000,2000,5000] as $a): ?>
          <div class="agrid-btn" data-val="<?= $a ?>" onclick="document.getElementById('amtInp').value=<?= $a ?>;this.closest('.amount-grid').querySelectorAll('.agrid-btn').forEach(b=>b.classList.remove('active'));this.classList.add('active');">₹<?= number_format($a) ?></div>
          <?php endforeach; ?>
        </div>
        <input class="form-input amount-main-inp" id="amtInp" type="number" name="amount" placeholder="Enter amount (min ₹100)" min="100"/>
      </div>
      <div class="form-group">
        <label class="form-label">🔖 UTR / Transaction ID</label>
        <input class="form-input" type="text" name="utr" placeholder="Enter UTR number after payment"/>
      </div>
      <input type="hidden" name="method" id="methodInp" value="upi"/>
      <button type="submit" class="submit-btn">Submit Deposit Request</button>
    </form>
  </div>
</div>

<!-- HISTORY -->
<div id="historyTab" style="display:none;">
  <div class="section">
    <?php if(empty($deps)): ?>
    <div class="empty-state"><div class="empty-icon">💳</div><div>No deposits yet</div></div>
    <?php else: foreach($deps as $d): ?>
    <div class="mybet-row">
      <div class="mybet-top">
        <div class="mybet-game">💳 <?= strtoupper($d['method']) ?></div>
        <div class="mybet-status status-<?= $d['status']==='approved'?'win':($d['status']==='rejected'?'loss':'pending') ?>"><?= strtoupper($d['status']) ?></div>
      </div>
      <div class="mybet-row-mid"><div>UTR: <b><?= $d['utr']?:'N/A' ?></b></div><div><?= date('d M H:i',strtotime($d['created_at'])) ?></div></div>
      <div class="mybet-amount win">+<?= money($d['amount']) ?></div>
    </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<script>
function selMethod(el, val) {
  document.querySelectorAll('.rmethod').forEach(r=>r.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('methodInp').value = val;
  document.getElementById('upiBox').style.display = val==='upi'?'block':'none';
}
function showRechargeTab(t) {
  document.getElementById('depositTab').style.display = t==='deposit'?'block':'none';
  document.getElementById('historyTab').style.display = t==='history'?'block':'none';
  document.getElementById('depositTabBtn').classList.toggle('active',t==='deposit');
  document.getElementById('historyTabBtn').classList.toggle('active',t==='history');
}
</script>
<?php include 'includes/footer.php'; ?>
