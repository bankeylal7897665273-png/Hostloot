<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'Win Go - 66Lottery';
$NAV_ACTIVE = 'home';
$gtype = clean($_GET['t'] ?? '1min');
if (!in_array($gtype,['1min','3min','5min','10min'])) $gtype='1min';
$secs_map = ['1min'=>60,'3min'=>180,'5min'=>300,'10min'=>600];
$secs = $secs_map[$gtype];

$db = db_connect();
// Get or create current period
$now = new DateTime();
$period_no = $now->format('Ymd').str_pad(floor(($now->getTimestamp()%86400)/$secs),4,'0',STR_PAD_LEFT);
$period = $db->prepare("SELECT * FROM wingo_periods WHERE period_no=? AND game_type=? LIMIT 1");
$period->execute([$period_no,$gtype]);
$period = $period->fetch();
if (!$period) {
    $close_time = new DateTime();
    $close_time->modify('+'.$secs.' seconds');
    $db->prepare("INSERT IGNORE INTO wingo_periods(period_no,game_type,status,open_time,close_time) VALUES(?,?,'open',NOW(),?)")
       ->execute([$period_no,$gtype,$close_time->format('Y-m-d H:i:s')]);
    $period = ['period_no'=>$period_no,'game_type'=>$gtype,'close_time'=>$close_time->format('Y-m-d H:i:s')];
}
$remaining = max(0, strtotime($period['close_time']) - time());

// Recent results
$results = $db->prepare("SELECT * FROM wingo_periods WHERE game_type=? AND status='closed' ORDER BY id DESC LIMIT 20");
$results->execute([$gtype]);
$results = $results->fetchAll();

// My bets
$mybets = $db->prepare("SELECT * FROM bets WHERE user_id=? AND game='wingo' ORDER BY id DESC LIMIT 20");
$mybets->execute([$_SESSION['uid']]);
$mybets = $mybets->fetchAll();

$me = me();
include 'includes/header.php';
?>

<!-- WIN GO HEADER -->
<div class="wingo-header">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
    <a href="/index.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">Win Go</div>
    <a href="/history.php" style="color:#fff;font-size:14px;">📋 Rules</a>
  </div>
</div>

<!-- GAME TYPE TABS -->
<div class="wingo-tabs">
  <button class="wingo-tab <?= $gtype==='1min'?'active':'' ?>" onclick="location.href='/wingo.php?t=1min'">1 Min</button>
  <button class="wingo-tab <?= $gtype==='3min'?'active':'' ?>" onclick="location.href='/wingo.php?t=3min'">3 Min</button>
  <button class="wingo-tab <?= $gtype==='5min'?'active':'' ?>" onclick="location.href='/wingo.php?t=5min'">5 Min</button>
  <button class="wingo-tab <?= $gtype==='10min'?'active':'' ?>" onclick="location.href='/wingo.php?t=10min'">10 Min</button>
</div>

<!-- PERIOD + TIMER -->
<div class="period-box">
  <div class="period-left">
    <div class="period-label">Period Number</div>
    <div class="period-no"><?= $period['period_no'] ?></div>
    <div style="margin-top:8px;font-size:12px;color:var(--muted);">Count Down</div>
    <div id="countTimer" class="timer-val"><?= sprintf('%02d:%02d', floor($remaining/60), $remaining%60) ?></div>
  </div>
  <div class="period-right">
    <div style="font-size:12px;color:var(--muted);margin-bottom:6px;">How to play</div>
    <div style="font-size:11px;color:var(--muted);line-height:1.6;">
      🟢 Green = Win 2x<br/>
      🔴 Red = Win 2x<br/>
      🟣 Violet = Win 4.5x<br/>
      🔢 Number = Win 9x<br/>
      📊 Big/Small = Win 2x
    </div>
  </div>
</div>

<!-- RECENT RESULTS -->
<div style="padding:0 12px 8px;">
  <div style="font-size:12px;color:var(--muted);margin-bottom:8px;">Recent Results</div>
  <div class="results-row">
    <?php if (empty($results)):
      $demo_colors = ['green','red','violet','red','green','green','red','violet','green','red'];
      $demo_nums   = [1,4,0,6,3,7,2,0,5,8];
      foreach(array_slice(array_keys($demo_colors),0,10) as $i): ?>
        <div class="rball <?= $demo_colors[$i] ?>"><?= $demo_nums[$i] ?></div>
      <?php endforeach;
    else: foreach($results as $r):
        $cls = $r['result_color'] ?? 'green';
    ?>
      <div class="rball <?= $cls ?>"><?= $r['result_num'] ?? '?' ?></div>
    <?php endforeach; endif; ?>
  </div>
</div>

<!-- COLOR BET BUTTONS -->
<div class="bet-panel">
  <div class="color-btns">
    <div class="cbtn green-btn" onclick="openBetModal('color','green','Green','green')">
      <div>Green</div>
      <div class="cbtn-sub">Win 2x</div>
    </div>
    <div class="cbtn violet-btn" onclick="openBetModal('color','violet','Violet','violet')">
      <div>Violet</div>
      <div class="cbtn-sub">Win 4.5x</div>
    </div>
    <div class="cbtn red-btn" onclick="openBetModal('color','red','Red','red')">
      <div>Red</div>
      <div class="cbtn-sub">Win 2x</div>
    </div>
  </div>

  <!-- NUMBER BUTTONS -->
  <div class="num-btns">
    <?php for($n=0;$n<=9;$n++):
      $ncls = $n==0?'n0':($n==5?'n5':($n%2==0?'n2':'n1'));
    ?>
    <div class="nbtn n<?= $n ?>" onclick="openBetModal('number','<?= $n ?>','Number <?= $n ?>','<?= $n==0?'violet':($n%2==0?'red':'green') ?>')"><?= $n ?></div>
    <?php endfor; ?>
  </div>

  <!-- BIG / SMALL -->
  <div class="size-btns">
    <div class="sbtn big-btn" onclick="openBetModal('size','big','Big (5-9)','red')">
      <div>Big</div>
      <div style="font-size:11px;margin-top:2px;font-weight:400;">5 6 7 8 9 · Win 2x</div>
    </div>
    <div class="sbtn small-btn" onclick="openBetModal('size','small','Small (0-4)','green')">
      <div>Small</div>
      <div style="font-size:11px;margin-top:2px;font-weight:400;">0 1 2 3 4 · Win 2x</div>
    </div>
  </div>
</div>

<!-- RESULT HISTORY TABLE -->
<div class="section">
  <div class="section-head">
    <div class="section-title">Win Go History</div>
  </div>
  <div style="display:flex;gap:6px;margin-bottom:10px;">
    <div class="page-tab active" data-target="histContent" onclick="switchWingoTab('hist')">Game History</div>
    <div class="page-tab" data-target="myContent" onclick="switchWingoTab('my')">My History</div>
  </div>

  <!-- GAME HISTORY -->
  <div id="histContent">
    <div class="hist-table">
      <div class="hist-row" style="background:var(--card2);">
        <div style="font-size:11px;color:var(--muted);flex:1;">Period</div>
        <div style="font-size:11px;color:var(--muted);width:60px;text-align:center;">Number</div>
        <div style="font-size:11px;color:var(--muted);width:70px;text-align:center;">Big/Small</div>
        <div style="font-size:11px;color:var(--muted);width:60px;text-align:center;">Color</div>
      </div>
      <?php if(empty($results)):
        $fakedata=[['g',1,'small'],['r',4,'small'],['v',0,'small'],['r',6,'big'],['g',3,'small'],['g',7,'big'],['r',2,'small'],['v',0,'small'],['g',5,'big'],['r',8,'big']];
        $clrnames=['g'=>'green','r'=>'red','v'=>'violet'];
        for($fi=0;$fi<8;$fi++):
          $fd=$fakedata[$fi];
          $cn=$clrnames[$fd[0]];
        ?>
        <div class="hist-row">
          <div class="hist-period" style="flex:1;"><div class="hist-period-no">202406<?= rand(10,28) ?>0<?= rand(1,9) ?></div></div>
          <div style="width:60px;text-align:center;"><div class="rball <?= $cn ?>" style="width:28px;height:28px;font-size:11px;margin:0 auto;"><?= $fd[1] ?></div></div>
          <div style="width:70px;text-align:center;font-size:12px;"><?= ucfirst($fd[2]) ?></div>
          <div style="width:60px;text-align:center;"><span style="color:var(--<?= $cn ?>);font-size:12px;font-weight:700;"><?= ucfirst($cn) ?></span></div>
        </div>
      <?php endfor;
      else: foreach($results as $r):
        $cn = $r['result_color'] ?? 'green'; ?>
        <div class="hist-row">
          <div class="hist-period" style="flex:1;"><div class="hist-period-no"><?= $r['period_no'] ?></div></div>
          <div style="width:60px;text-align:center;"><div class="rball <?= $cn ?>" style="width:28px;height:28px;font-size:11px;margin:0 auto;"><?= $r['result_num'] ?></div></div>
          <div style="width:70px;text-align:center;font-size:12px;"><?= ucfirst($r['result_size']??'') ?></div>
          <div style="width:60px;text-align:center;"><span style="color:var(--<?= $cn ?>);font-size:12px;font-weight:700;"><?= ucfirst($cn) ?></span></div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <!-- MY HISTORY -->
  <div id="myContent" style="display:none;">
    <?php if(empty($mybets)): ?>
    <div class="empty-state"><div class="empty-icon">📋</div><div>No bets yet. Place your first bet!</div></div>
    <?php else: foreach($mybets as $b):
      $bdata = json_decode($b['bet_data']??'{}',true);
    ?>
    <div class="mybet-row">
      <div class="mybet-top">
        <div class="mybet-game">Win Go · <?= $gtype ?></div>
        <div class="mybet-status status-<?= $b['status'] ?>"><?= strtoupper($b['status']) ?></div>
      </div>
      <div class="mybet-row-mid">
        <div>Bet: <b><?= ucfirst($b['bet_value']) ?></b></div>
        <div>Period: <b><?= $b['period_no'] ?></b></div>
      </div>
      <div class="mybet-amount <?= $b['status']==='win'?'win':($b['status']==='loss'?'loss':'') ?>">
        <?= $b['status']==='win' ? '+'.money($b['win_amount']) : '-'.money($b['amount']) ?>
      </div>
    </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<!-- BET MODAL -->
<div class="modal-overlay" id="betModal">
  <div class="modal-box">
    <div class="modal-head">
      <div class="modal-title">Win Go · <?= strtoupper($gtype) ?></div>
      <div class="modal-close" onclick="closeModal('betModal')">✕</div>
    </div>
    <div class="modal-body">
      <div class="modal-sel">
        <div class="rball sel-ball green" id="selBall"></div>
        <div>
          <div class="sel-label" id="selLabel">Green</div>
          <div style="font-size:11px;color:var(--muted);">Win 2x multiplier</div>
        </div>
      </div>
      <div class="modal-label">Select Amount</div>
      <div class="amount-btns">
        <div class="amt-btn" data-val="10">₹10</div>
        <div class="amt-btn" data-val="50">₹50</div>
        <div class="amt-btn" data-val="100">₹100</div>
        <div class="amt-btn" data-val="500">₹500</div>
        <div class="amt-btn" data-val="1000">₹1K</div>
        <div class="amt-btn" data-val="x5">×5</div>
        <div class="amt-btn" data-val="x10">×10</div>
      </div>
      <input type="number" id="betAmountInp" class="amt-input" placeholder="Enter amount" value="10" min="10" oninput="updateModalInfo()"/>
      <div class="modal-info">
        <div class="modal-info-row"><span>Amount</span><span id="infoAmt">₹10.00</span></div>
        <div class="modal-info-row"><span>Fee (2%)</span><span id="infoFee">₹0.20</span></div>
        <div class="modal-info-row"><span>After Fee</span><span id="infoAfter">₹9.80</span></div>
      </div>
      <div style="font-size:11px;color:var(--muted);margin-bottom:12px;">Balance: <span class="balance-val"><?= money($me['balance']) ?></span></div>
      <button class="modal-confirm" onclick="placeBet('wingo')">✅ Confirm Bet</button>
    </div>
  </div>
</div>

<script>
startTimer(<?= $remaining ?>, 'countTimer', () => location.reload());

function switchWingoTab(t) {
  document.getElementById('histContent').style.display = t==='hist'?'block':'none';
  document.getElementById('myContent').style.display = t==='my'?'block':'none';
  document.querySelectorAll('.page-tab').forEach(el=>{
    el.classList.toggle('active', (t==='hist'&&el.dataset.target==='histContent')||(t==='my'&&el.dataset.target==='myContent'));
  });
}
</script>
<?php include 'includes/footer.php'; ?>
