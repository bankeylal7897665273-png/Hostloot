<?php
define('BASE_PATH', '');
$page_title  = 'Win Go';
$active_page = 'wingo';
require_once 'config.php';
require_once 'includes/auth.php';
if (!is_logged_in()) redirect('login.php');
$user = get_current_user_data();
?>
<?php include 'includes/header.php'; ?>

<div class="section-header">
  <div class="section-title">Win <span>Go</span></div>
  <div style="display:flex;gap:8px;">
    <a href="wingo.php?t=1" class="btn btn--outline" style="font-size:12px;padding:6px 12px;">1 Min</a>
    <a href="wingo.php?t=3" class="btn btn--outline" style="font-size:12px;padding:6px 12px;">3 Min</a>
    <a href="wingo.php?t=5" class="btn btn--outline" style="font-size:12px;padding:6px 12px;">5 Min</a>
  </div>
</div>

<div class="wingo-panel">

  <!-- LEFT: Bet Panel -->
  <div class="card">
    <div class="timer-ring">
      <div class="timer-ring__period">Period #<?= date('YmdHi') ?></div>
      <div class="timer-ring__time" id="wingoTimer">01:00</div>
      <div class="timer-ring__label">Time Remaining</div>
    </div>

    <!-- Recent Results -->
    <div class="card__title">Recent Results</div>
    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:20px;" id="recentResults">
      <?php
      $db = db_connect();
      $results = $db->query("SELECT * FROM lottery_draws WHERE draw_type='wingo' ORDER BY id DESC LIMIT 10")->fetchAll();
      if (empty($results)):
        for ($i=0; $i<8; $i++):
          $n = rand(0,9);
          $c = $n == 0 ? 'violet' : ($n % 2 == 0 ? 'red' : 'green');
          $cls = "ball-$c";
      ?>
        <div class="result-ball <?= $cls ?>"><?= $n ?></div>
      <?php endfor; else: foreach($results as $r):
          $cls = 'ball-' . ($r['color'] ?? 'green');
      ?>
        <div class="result-ball <?= $cls ?>"><?= $r['result'] ?></div>
      <?php endforeach; endif; ?>
    </div>

    <!-- Bet Options -->
    <div class="card__title">Place Your Bet</div>
    <input type="hidden" id="betSelection" value=""/>

    <div class="bet-options">
      <div class="bet-option green-opt" data-value="green" style="color:#00e676;">
        <div style="font-weight:700;font-size:15px;">Green</div>
        <div style="font-size:11px;color:#6b6b8f;">Win 2x</div>
      </div>
      <div class="bet-option" data-value="violet" style="color:#9c27b0;">
        <div style="font-weight:700;font-size:15px;">Violet</div>
        <div style="font-size:11px;color:#6b6b8f;">Win 4.5x</div>
      </div>
      <div class="bet-option red-opt" data-value="red" style="color:#ff1744;">
        <div style="font-weight:700;font-size:15px;">Red</div>
        <div style="font-size:11px;color:#6b6b8f;">Win 2x</div>
      </div>
    </div>

    <div style="margin-bottom:10px;font-size:12px;color:#6b6b8f;letter-spacing:.5px;">OR BET ON NUMBER</div>
    <div class="bet-options" style="grid-template-columns:repeat(5,1fr);">
      <?php for($n=0; $n<=9; $n++): ?>
      <div class="bet-option" data-value="<?= $n ?>" style="padding:10px 4px;">
        <div style="font-family:'Rajdhani',sans-serif;font-size:18px;font-weight:700;"><?= $n ?></div>
      </div>
      <?php endfor; ?>
    </div>

    <div style="margin-bottom:10px;font-size:12px;color:#6b6b8f;letter-spacing:.5px;margin-top:16px;">BIG / SMALL</div>
    <div class="bet-options">
      <div class="bet-option" data-value="big"  ><div style="font-weight:700;">Big</div><div style="font-size:11px;color:#6b6b8f;">5-9 • 2x</div></div>
      <div class="bet-option" data-value="small"><div style="font-weight:700;">Small</div><div style="font-size:11px;color:#6b6b8f;">0-4 • 2x</div></div>
    </div>

    <!-- Bet Amount -->
    <div style="margin-top:16px;" class="card__title">Bet Amount</div>
    <div class="quick-bets">
      <?php foreach([10, 50, 100, 500, 1000, 5000] as $amt): ?>
      <div class="quick-bet" data-amount="<?= $amt ?>">₹<?= $amt ?></div>
      <?php endforeach; ?>
    </div>
    <div class="bet-amount-row">
      <input type="number" id="betAmount" placeholder="Enter amount (min ₹10)" min="10" max="10000" value="10"/>
    </div>
    <button class="btn btn--primary btn--full btn--lg" onclick="placeBet('wingo-1min')">
      <i class="fa fa-dice"></i> Place Bet
    </button>
  </div>

  <!-- RIGHT: History -->
  <div>
    <div class="card">
      <div class="card__title">My Bet History</div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Period</th><th>Bet</th><th>Amount</th><th>Result</th></tr></thead>
          <tbody>
            <?php
            $bets = $db->prepare("SELECT b.*, ld.result, ld.color FROM bets b LEFT JOIN lottery_draws ld ON ld.period=b.bet_data->>'$.period' WHERE b.user_id=? AND b.game_id=1 ORDER BY b.id DESC LIMIT 15");
            $bets->execute([$user['id']]);
            $rows = $bets->fetchAll();
            if (empty($rows)):
            ?>
            <tr><td colspan="4" style="text-align:center;color:#6b6b8f;padding:20px;">No bets yet. Place your first bet!</td></tr>
            <?php else: foreach($rows as $b): ?>
            <tr>
              <td><?= date('H:i', strtotime($b['created_at'])) ?></td>
              <td><?= htmlspecialchars(json_decode($b['bet_data'] ?? '{}', true)['selection'] ?? '-') ?></td>
              <td><?= format_currency($b['bet_amount']) ?></td>
              <td><span class="badge badge-<?= $b['result'] ?>"><?= strtoupper($b['result']) ?></span></td>
            </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
