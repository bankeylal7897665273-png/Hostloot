<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'Activity - 66Lottery';
$NAV_ACTIVE = 'activity';
include 'includes/header.php';
?>
<div class="wingo-header">
  <div style="font-size:17px;font-weight:800;">Activity & Bonus</div>
</div>
<div class="section" style="margin-top:12px;">
  <div class="game-grid">
    <a href="/gift.php" class="game-card">
      <div class="game-thumb" style="background:linear-gradient(135deg,#3a2a00,#8a6000);">🎁</div>
      <div class="game-info"><div class="game-name">Gift Card</div><div class="game-desc">Redeem codes</div></div>
    </a>
    <a href="/invite.php" class="game-card">
      <div class="game-thumb" style="background:linear-gradient(135deg,#1a1a3a,#3a3a8a);">👥</div>
      <div class="game-info"><div class="game-name">Invite</div><div class="game-desc">Earn ₹50/refer</div></div>
    </a>
    <a href="/vip.php" class="game-card">
      <div class="game-thumb" style="background:linear-gradient(135deg,#3a2a00,#5c4500);">⭐</div>
      <div class="game-info"><div class="game-name">VIP Club</div><div class="game-desc">Exclusive rewards</div></div>
    </a>
  </div>
  <div style="margin-top:16px;background:linear-gradient(135deg,#1a3a2a,#003820);border:1px solid rgba(0,185,107,.3);border-radius:16px;padding:18px;text-align:center;">
    <div style="font-size:24px;margin-bottom:6px;">🎰</div>
    <div style="font-size:15px;font-weight:800;color:var(--green);">Daily Login Bonus</div>
    <div style="font-size:12px;color:var(--muted);margin:6px 0 12px;">Login every day to claim bonus!</div>
    <button class="submit-btn" style="max-width:200px;padding:10px;" onclick="toast('✅ Daily bonus claimed! ₹5 added!')">Claim ₹5 Now</button>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
