<?php
require_once 'config.php';
require_once 'includes/auth.php';
if (is_logged_in()) redirect('index.php');

$error = ''; $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $email    = sanitize($_POST['email'] ?? '');
    $phone    = sanitize($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    $referral = sanitize($_POST['referral'] ?? '');

    if (!$username || !$email || !$password) {
        $error = 'Username, email and password are required.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $result = register_user($username, $email, $phone, $password, $referral ?: null);
        if ($result['success']) {
            login_user($email, $password);
            redirect('index.php');
        } else {
            $error = $result['error'];
        }
    }
}
$ref_param = $_GET['ref'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title><?= SITE_NAME ?> – Register</title>
  <link rel="stylesheet" href="assets/css/style.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
<div class="auth-wrap">
  <div class="auth-box">
    <div class="auth-logo">
      <span class="logo-icon">🎰</span>
      <span class="logo-text"><?= SITE_NAME ?></span>
      <p style="color:#6b6b8f;font-size:12px;margin-top:4px;">Create Your Account</p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error"><i class="fa fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" placeholder="Choose a username" required/>
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" placeholder="Enter your email" required/>
      </div>
      <div class="form-group">
        <label>Phone (optional)</label>
        <input type="tel" name="phone" placeholder="+91 XXXXXXXXXX"/>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Min 6 characters" required/>
      </div>
      <div class="form-group">
        <label>Confirm Password</label>
        <input type="password" name="confirm_password" placeholder="Repeat password" required/>
      </div>
      <div class="form-group">
        <label>Referral Code (optional)</label>
        <input type="text" name="referral" placeholder="Enter referral code" value="<?= htmlspecialchars($ref_param) ?>"/>
      </div>
      <button type="submit" class="btn btn--primary btn--full btn--lg" style="margin-top:8px;">
        <i class="fa fa-user-plus"></i> Create Account
      </button>
    </form>
    <div class="auth-footer">
      Already have an account? <a href="login.php">Login</a>
    </div>
  </div>
</div>
</body>
</html>
