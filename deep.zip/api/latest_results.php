<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';

$db      = db_connect();
$results = $db->query("SELECT result, color FROM lottery_draws WHERE draw_type='wingo' AND status='complete' ORDER BY id DESC LIMIT 10")->fetchAll();

// If no real data, return random demo
if (empty($results)) {
    $demo = [];
    for ($i = 0; $i < 10; $i++) {
        $n = rand(0, 9);
        $c = $n == 0 ? 'violet' : ($n % 2 == 0 ? 'red' : 'green');
        $demo[] = ['result' => $n, 'color' => $c];
    }
    $results = $demo;
}

echo json_encode(['results' => $results]);
