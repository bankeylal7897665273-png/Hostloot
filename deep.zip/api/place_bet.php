<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) { echo json_encode(['success' => false, 'error' => 'Not logged in.']); exit; }

$input = json_decode(file_get_contents('php://input'), true);
$game      = sanitize($input['game'] ?? '');
$selection = sanitize($input['selection'] ?? '');
$amount    = floatval($input['amount'] ?? 0);

if ($amount < MIN_BET || $amount > MAX_BET) {
    echo json_encode(['success' => false, 'error' => 'Bet amount out of range.']); exit;
}
if (!$selection) {
    echo json_encode(['success' => false, 'error' => 'No selection made.']); exit;
}

$db   = db_connect();
$user = get_current_user_data();

if ($user['balance'] < $amount) {
    echo json_encode(['success' => false, 'error' => 'Insufficient balance.']); exit;
}

// Get game id
$g_stmt = $db->prepare("SELECT * FROM games WHERE slug=? AND is_active=1 LIMIT 1");
$g_stmt->execute([$game]);
$game_row = $g_stmt->fetch();
if (!$game_row) { echo json_encode(['success' => false, 'error' => 'Game not found.']); exit; }

// Deduct balance
$db->prepare("UPDATE users SET balance = balance - ? WHERE id=?")->execute([$amount, $user['id']]);

// Insert bet (result will be processed by cron/draw)
$period = date('YmdHi');
$db->prepare("INSERT INTO bets (user_id, game_id, bet_amount, result, bet_data) VALUES (?,?,?,'pending',?)")
   ->execute([$user['id'], $game_row['id'], $amount, json_encode(['selection' => $selection, 'period' => $period])]);

$new_balance = $user['balance'] - $amount;
$_SESSION['balance'] = $new_balance;

echo json_encode(['success' => true, 'new_balance' => number_format($new_balance, 2), 'period' => $period]);
