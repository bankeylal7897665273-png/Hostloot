<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';
if (!is_logged_in()) { echo json_encode(['success'=>false,'error'=>'Login required']); exit; }

$data = json_decode(file_get_contents('php://input'), true);
$game   = clean($data['game']??'');
$type   = clean($data['type']??'');
$value  = clean($data['value']??'');
$amount = floatval($data['amount']??0);

if ($amount < MIN_BET) { echo json_encode(['success'=>false,'error'=>'Minimum bet ₹'.MIN_BET]); exit; }
if ($amount > MAX_BET) { echo json_encode(['success'=>false,'error'=>'Maximum bet ₹'.number_format(MAX_BET)]); exit; }
if (!$game||!$type||!$value) { echo json_encode(['success'=>false,'error'=>'Invalid bet data']); exit; }

$db = db_connect();
$me = me();
if ($me['balance'] < $amount) { echo json_encode(['success'=>false,'error'=>'Insufficient balance']); exit; }

$fee = round($amount * 0.02, 2);
$now = time(); $secs = 60;
$period_no = date('Ymd').str_pad(floor(($now%86400)/$secs),4,'0',STR_PAD_LEFT);

// Deduct balance
$db->prepare("UPDATE users SET balance=balance-? WHERE id=?")->execute([$amount, $_SESSION['uid']]);

// Insert bet
$db->prepare("INSERT INTO bets(user_id,game,period_no,bet_type,bet_value,amount,fee,status) VALUES(?,?,?,?,?,?,?,'pending')")
   ->execute([$_SESSION['uid'], $game, $period_no, $type, $value, $amount, $fee]);

$new_balance = $me['balance'] - $amount;
echo json_encode(['success'=>true, 'balance'=>number_format($new_balance,2), 'period'=>$period_no]);
