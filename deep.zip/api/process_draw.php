<?php
/**
 * CRON: Run every minute
 * * * * * php /var/www/html/api/process_draw.php
 */
require_once __DIR__ . '/../config.php';

$db = db_connect();
$now = time(); $secs = 60;
$prev_secs = $now - $secs;
$period_no = date('Ymd', $prev_secs).str_pad(floor(($prev_secs%86400)/$secs),4,'0',STR_PAD_LEFT);

// Check already processed
$chk = $db->prepare("SELECT id FROM wingo_periods WHERE period_no=? AND game_type='1min' AND status='closed'");
$chk->execute([$period_no]);
if ($chk->fetch()) { echo "Already done: $period_no\n"; exit; }

// Generate result
$result_num   = rand(0,9);
$result_color = ($result_num==0)?'violet':(($result_num%2==0)?'red':'green');
if ($result_num==5) $result_color='violet';
$result_size  = ($result_num>=5)?'big':'small';

// Save or update period
$db->prepare("INSERT INTO wingo_periods(period_no,game_type,result_num,result_color,result_size,status,open_time,close_time)
  VALUES(?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE result_num=VALUES(result_num),result_color=VALUES(result_color),result_size=VALUES(result_size),status='closed'")
->execute([$period_no,'1min',$result_num,$result_color,$result_size,'closed',date('Y-m-d H:i:s',$prev_secs),date('Y-m-d H:i:s',$now)]);

// Process pending bets
$bets = $db->prepare("SELECT * FROM bets WHERE game='wingo' AND period_no=? AND status='pending'");
$bets->execute([$period_no]);
$bets = $bets->fetchAll();

$multipliers = ['green'=>2,'red'=>2,'violet'=>4.5,'big'=>2,'small'=>2,'number'=>9];
foreach ($bets as $bet) {
    $won = false; $multi = 0;
    if ($bet['bet_type']==='color' && $bet['bet_value']===$result_color) { $won=true; $multi=$multipliers[$result_color]; }
    elseif ($bet['bet_type']==='size' && $bet['bet_value']===$result_size) { $won=true; $multi=2; }
    elseif ($bet['bet_type']==='number' && intval($bet['bet_value'])===$result_num) { $won=true; $multi=9; }

    $after_fee = $bet['amount'] - $bet['fee'];
    $win_amount = $won ? round($after_fee * $multi, 2) : 0;
    $status = $won ? 'win' : 'loss';

    $db->prepare("UPDATE bets SET status=?,win_amount=? WHERE id=?")->execute([$status,$win_amount,$bet['id']]);
    if ($won) {
        $db->prepare("UPDATE users SET balance=balance+?,total_won=total_won+? WHERE id=?")->execute([$win_amount,$win_amount,$bet['user_id']]);
    }
}

// Also process K3
$k3_period = $period_no;
$d1=rand(1,6); $d2=rand(1,6); $d3=rand(1,6); $total=$d1+$d2+$d3;
$k3_size = $total>=11?'big':'small';
$k3_parity = $total%2===0?'even':'odd';

$db->prepare("INSERT INTO k3_periods(period_no,game_type,dice1,dice2,dice3,total,result_size,result_parity,status,open_time,close_time)
  VALUES(?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE dice1=VALUES(dice1),dice2=VALUES(dice2),dice3=VALUES(dice3),total=VALUES(total),result_size=VALUES(result_size),result_parity=VALUES(result_parity),status='closed'")
->execute([$k3_period,'1min',$d1,$d2,$d3,$total,$k3_size,$k3_parity,'closed',date('Y-m-d H:i:s',$prev_secs),date('Y-m-d H:i:s',$now)]);

$k3bets = $db->prepare("SELECT * FROM bets WHERE game='k3' AND period_no=? AND status='pending'");
$k3bets->execute([$k3_period]); $k3bets=$k3bets->fetchAll();
foreach($k3bets as $bet) {
    $won=false; $multi=0;
    if ($bet['bet_type']==='k3_total' && $bet['bet_value']===$k3_size) { $won=true; $multi=2; }
    elseif ($bet['bet_type']==='k3_parity' && $bet['bet_value']===$k3_parity) { $won=true; $multi=2; }
    elseif ($bet['bet_type']==='k3_sum' && intval($bet['bet_value'])===$total) { $won=true; $multi=15; }
    $after_fee=$bet['amount']-$bet['fee'];
    $win_amount=$won?round($after_fee*$multi,2):0;
    $status=$won?'win':'loss';
    $db->prepare("UPDATE bets SET status=?,win_amount=? WHERE id=?")->execute([$status,$win_amount,$bet['id']]);
    if($won) $db->prepare("UPDATE users SET balance=balance+?,total_won=total_won+? WHERE id=?")->execute([$win_amount,$win_amount,$bet['user_id']]);
}

echo "Draw processed: $period_no | Num:$result_num Color:$result_color | K3:$d1+$d2+$d3=$total\n";
