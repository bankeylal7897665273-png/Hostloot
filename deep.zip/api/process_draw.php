<?php
/**
 * CRON JOB – Run every minute to process Win Go 1Min draw
 * Add to crontab: * * * * * php /path/to/api/process_draw.php
 */
require_once __DIR__ . '/../config.php';

$db     = db_connect();
$period = date('YmdHi', strtotime('-1 minute')); // Last period

// Check if already processed
$check = $db->prepare("SELECT id FROM lottery_draws WHERE period=? AND draw_type='wingo'");
$check->execute([$period]);
if ($check->fetch()) exit; // Already processed

// Generate result
$result = rand(0, 9);
$color  = $result == 0 ? 'violet' : ($result % 2 == 0 ? 'red' : 'green');
$big    = $result >= 5 ? 'big' : 'small';
$odd    = $result % 2 == 0 ? 'even' : 'odd';

// Save draw
$db->prepare("INSERT INTO lottery_draws (draw_type, period, result, big_small, odd_even, color, status) VALUES ('wingo', ?, ?, ?, ?, ?, 'complete')")
   ->execute([$period, $result, $big, $odd, $color]);

// Process bets for this period
$bets = $db->prepare("SELECT * FROM bets WHERE result='pending' AND bet_data->>'$.period'=?");
$bets->execute([$period]);
$bets = $bets->fetchAll();

foreach ($bets as $bet) {
    $data      = json_decode($bet['bet_data'], true);
    $selection = $data['selection'] ?? '';
    $is_win    = false;
    $multiplier = 0;

    if ($selection === 'red' && $color === 'red')       { $is_win = true; $multiplier = 2; }
    elseif ($selection === 'green' && $color === 'green') { $is_win = true; $multiplier = 2; }
    elseif ($selection === 'violet' && $color === 'violet') { $is_win = true; $multiplier = 4.5; }
    elseif ($selection === 'big' && $big === 'big')     { $is_win = true; $multiplier = 2; }
    elseif ($selection === 'small' && $big === 'small') { $is_win = true; $multiplier = 2; }
    elseif (is_numeric($selection) && intval($selection) === $result) { $is_win = true; $multiplier = 9; }

    $win_amount = $is_win ? $bet['bet_amount'] * $multiplier : 0;
    $res_str    = $is_win ? 'win' : 'loss';

    $db->prepare("UPDATE bets SET result=?, win_amount=? WHERE id=?")->execute([$res_str, $win_amount, $bet['id']]);

    if ($is_win) {
        $db->prepare("UPDATE users SET balance = balance + ?, total_won = total_won + ? WHERE id=?")
           ->execute([$win_amount, $win_amount, $bet['user_id']]);
    }
}

echo "Draw processed: Period=$period Result=$result Color=$color\n";
