<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'Trx Win Go - 66Lottery';
$NAV_ACTIVE = 'home';
$me = me();
$now = time(); $secs = 60;
$rem = $secs - ($now % $secs);
$period_no = 'TRX'.date('YmdHi');
include 'includes/header.php';
?>
<div class="wingo-header">
  <div style="display:flex;align-items:center;justify-content:space-between;">
    <a href="/index.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">Trx Win Go</div>
    <div style="font-size:14px;">💎</div>
  </div>
</div>
<div class="wingo-tabs" style="padding:8px 12px 10px;">
  <button class="wingo-tab active">1 Min</button>
  <button class="wingo-tab">3 Min</button>
  <button class="wingo-tab">5 Min</button>
</div>

<div style="background:rgba(122,82,201,.1);border:1px solid rgba(122,82,201,.3);margin:12px;border-radius:10px;padding:10px 14px;display:flex;align-items:center;gap:8px;font-size:12px;color:#b07cf5;">
  💎 Results based on TRON blockchain hash — 100% Fair & Transparent
</div>

<div class="period-box">
  <div>
    <div class="period-label">Period</div>
    <div class="period-no" style="font-size:14px;"><?= $period_no ?></div>
    <div style="font-size:12px;color:var(--muted);margin-top:8px;">Count Down</div>
    <div id="countTimer" class="timer-val"><?= sprintf('%02d:%02d',floor($rem/60),$rem%60) ?></div>
  </div>
  <div style="text-align:right;">
    <div style="font-size:11px;color:var(--muted);">Last Block Hash</div>
    <div style="font-size:10px;color:#b07cf5;word-break:break-all;max-width:160px;margin-top:4px;">0x7f3a...9e2d</div>
    <a href="https://tronscan.org" target="_blank" style="font-size:11px;color:var(--green);display:block;margin-top:4px;">Verify on TronScan →</a>
  </div>
</div>

<!-- COLOR BTNS -->
<div class="bet-panel">
  <div class="color-btns">
    <div class="cbtn green-btn" onclick="openBetModal('color','green','Green','green')"><div>Green</div><div class="cbtn-sub">Win 2x</div></div>
    <div class="cbtn violet-btn" onclick="openBetModal('color','violet','Violet','violet')"><div>Violet</div><div class="cbtn-sub">Win 4.5x</div></div>
    <div class="cbtn red-btn" onclick="openBetModal('color','red','Red','red')"><div>Red</div><div class="cbtn-sub">Win 2x</div></div>
  </div>
  <div class="num-btns">
    <?php for($n=0;$n<=9;$n++): ?>
    <div class="nbtn n<?= $n ?>" onclick="openBetModal('number','<?= $n ?>','Number <?= $n ?>','<?= $n==0?'violet':($n%2==0?'red':'green') ?>')"><?= $n ?></div>
    <?php endfor; ?>
  </div>
  <div class="size-btns">
    <div class="sbtn big-btn" onclick="openBetModal('size','big','Big (5-9)','red')"><div>Big</div><div style="font-size:11px;">5-9 · Win 2x</div></div>
    <div class="sbtn small-btn" onclick="openBetModal('size','small','Small (0-4)','green')"><div>Small</div><div style="font-size:11px;">0-4 · Win 2x</div></div>
  </div>
</div>

<!-- RECENT RESULTS -->
<div style="padding:0 12px 8px;">
  <div style="font-size:12px;color:var(--muted);margin-bottom:8px;">Recent Results</div>
  <div class="results-row">
    <?php
    $colors=['green','red','violet','red','green','green','red','violet','green','red'];
    $nums=[1,4,0,6,3,7,2,0,5,8];
    for($i=0;$i<10;$i++): ?>
    <div class="rball <?= $colors[$i] ?>"><?= $nums[$i] ?></div>
    <?php endfor; ?>
  </div>
</div>

<!-- BET MODAL -->
<div class="modal-overlay" id="betModal">
  <div class="modal-box">
    <div class="modal-head"><div class="modal-title">Trx Win Go · 1 Min</div><div class="modal-close" onclick="closeModal('betModal')">✕</div></div>
    <div class="modal-body">
      <div class="modal-sel"><div class="rball sel-ball green" id="selBall"></div><div><div class="sel-label" id="selLabel">Green</div><div style="font-size:11px;color:var(--muted);">Win 2x</div></div></div>
      <div class="amount-btns">
        <div class="amt-btn" data-val="10">₹10</div><div class="amt-btn" data-val="50">₹50</div>
        <div class="amt-btn" data-val="100">₹100</div><div class="amt-btn" data-val="500">₹500</div>
        <div class="amt-btn" data-val="1000">₹1K</div><div class="amt-btn" data-val="x5">×5</div>
      </div>
      <input type="number" id="betAmountInp" class="amt-input" value="10" min="10" oninput="updateModalInfo()"/>
      <div class="modal-info">
        <div class="modal-info-row"><span>Amount</span><span id="infoAmt">₹10.00</span></div>
        <div class="modal-info-row"><span>Fee (2%)</span><span id="infoFee">₹0.20</span></div>
        <div class="modal-info-row"><span>After Fee</span><span id="infoAfter">₹9.80</span></div>
      </div>
      <div style="font-size:11px;color:var(--muted);margin-bottom:12px;">Balance: <span class="balance-val"><?= money($me['balance']) ?></span></div>
      <button class="modal-confirm" onclick="placeBet('trx')">✅ Confirm Bet</button>
    </div>
  </div>
</div>
<script>startTimer(<?= $rem ?>,'countTimer',()=>location.reload());</script>
<?php include 'includes/footer.php'; ?>
