<?php
define('BASE_PATH', '');
$page_title  = 'Wallet';
$active_page = 'wallet';
require_once 'config.php';
require_once 'includes/auth.php';
if (!is_logged_in()) redirect('login.php');
$user  = get_current_user_data();
$db    = db_connect();
$tab   = sanitize($_GET['tab'] ?? 'deposit');
$msg   = ''; $msg_type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = floatval($_POST['amount'] ?? 0);
    $method = sanitize($_POST['method'] ?? '');
    if ($amount < 100) { $msg = 'Minimum amount is ₹100.'; $msg_type = 'error'; }
    elseif (!$method)  { $msg = 'Please select a payment method.'; $msg_type = 'error'; }
    elseif ($_POST['type'] === 'deposit') {
        $db->prepare("INSERT INTO deposits (user_id,amount,method,status) VALUES (?,?,?,'pending')")->execute([$user['id'], $amount, $method]);
        $msg = 'Deposit request submitted! We will process within 10 minutes.';
    } elseif ($_POST['type'] === 'withdraw') {
        $account = sanitize($_POST['account'] ?? '');
        if ($amount > $user['balance']) { $msg = 'Insufficient balance.'; $msg_type = 'error'; }
        else {
            $db->prepare("INSERT INTO withdrawals (user_id,amount,method,account,status) VALUES (?,?,?,?,'pending')")->execute([$user['id'], $amount, $method, $account]);
            $msg = 'Withdrawal request submitted! Processing within 24 hours.';
        }
    }
}

$deposits    = $db->prepare("SELECT * FROM deposits WHERE user_id=? ORDER BY id DESC LIMIT 10"); $deposits->execute([$user['id']]); $deposits = $deposits->fetchAll();
$withdrawals = $db->prepare("SELECT * FROM withdrawals WHERE user_id=? ORDER BY id DESC LIMIT 10"); $withdrawals->execute([$user['id']]); $withdrawals = $withdrawals->fetchAll();
?>
<?php include 'includes/header.php'; ?>

<div class="section-title mb-4">My <span>Wallet</span></div>

<!-- Balance Card -->
<div class="card mb-6" style="background:linear-gradient(135deg,#1a0533,#0d2347);border-color:#7c3aed;">
  <div style="font-size:12px;color:#6b6b8f;letter-spacing:1px;text-transform:uppercase;">Available Balance</div>
  <div style="font-family:'Rajdhani',sans-serif;font-size:44px;font-weight:700;color:#ffd600;margin:6px 0;"><?= format_currency($user['balance']) ?></div>
  <div style="display:flex;gap:10px;margin-top:10px;">
    <a href="?tab=deposit"  class="btn btn--green" style="font-size:13px;"><i class="fa fa-plus"></i> Deposit</a>
    <a href="?tab=withdraw" class="btn btn--outline" style="font-size:13px;"><i class="fa fa-minus"></i> Withdraw</a>
  </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-<?= $msg_type ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<!-- Tabs -->
<div style="display:flex;gap:4px;margin-bottom:20px;background:var(--bg-card);border-radius:var(--radius);padding:4px;">
  <a href="?tab=deposit"  class="btn <?= $tab=='deposit'  ? 'btn--primary' : '' ?>" style="flex:1;justify-content:center;border-radius:10px;">Deposit</a>
  <a href="?tab=withdraw" class="btn <?= $tab=='withdraw' ? 'btn--primary' : '' ?>" style="flex:1;justify-content:center;border-radius:10px;">Withdraw</a>
  <a href="?tab=history"  class="btn <?= $tab=='history'  ? 'btn--primary' : '' ?>" style="flex:1;justify-content:center;border-radius:10px;">History</a>
</div>

<?php if ($tab === 'deposit'): ?>
<div class="card">
  <div class="card__title">Add Funds</div>
  <form method="POST">
    <input type="hidden" name="type" value="deposit"/>
    <div class="form-group">
      <label>Amount (Min ₹100)</label>
      <input type="number" name="amount" placeholder="Enter amount" min="100" required/>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;">
      <?php foreach([100,500,1000,5000,10000] as $a): ?>
      <div class="quick-bet" data-amount="<?= $a ?>" onclick="document.querySelector('[name=amount]').value=<?= $a ?>">₹<?= number_format($a) ?></div>
      <?php endforeach; ?>
    </div>
    <div class="form-group">
      <label>Payment Method</label>
      <select name="method" style="width:100%;background:var(--bg-deep);border:1px solid var(--border);color:var(--text);border-radius:8px;padding:11px 14px;font-size:14px;">
        <option value="">Select method</option>
        <option value="upi">UPI</option>
        <option value="netbanking">Net Banking</option>
        <option value="card">Debit/Credit Card</option>
        <option value="crypto">Crypto (USDT)</option>
      </select>
    </div>
    <button type="submit" class="btn btn--green btn--full btn--lg"><i class="fa fa-arrow-down"></i> Request Deposit</button>
  </form>
</div>

<?php elseif ($tab === 'withdraw'): ?>
<div class="card">
  <div class="card__title">Withdraw Funds</div>
  <form method="POST">
    <input type="hidden" name="type" value="withdraw"/>
    <div class="form-group">
      <label>Amount (Available: <?= format_currency($user['balance']) ?>)</label>
      <input type="number" name="amount" placeholder="Enter amount" min="100" max="<?= $user['balance'] ?>" required/>
    </div>
    <div class="form-group">
      <label>Withdrawal Method</label>
      <select name="method" style="width:100%;background:var(--bg-deep);border:1px solid var(--border);color:var(--text);border-radius:8px;padding:11px 14px;font-size:14px;" id="wMethodSel">
        <option value="">Select method</option>
        <option value="upi">UPI</option>
        <option value="bank">Bank Transfer</option>
        <option value="crypto">Crypto (USDT)</option>
      </select>
    </div>
    <div class="form-group">
      <label>Account Details (UPI ID / Account No / Wallet)</label>
      <input type="text" name="account" placeholder="Enter your account info" required/>
    </div>
    <button type="submit" class="btn btn--primary btn--full btn--lg"><i class="fa fa-arrow-up"></i> Request Withdrawal</button>
  </form>
</div>

<?php else: ?>
<div class="card">
  <div class="card__title">Deposit History</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Status</th></tr></thead>
      <tbody>
        <?php if (empty($deposits)): ?>
        <tr><td colspan="4" style="text-align:center;color:#6b6b8f;padding:20px;">No deposits yet.</td></tr>
        <?php else: foreach($deposits as $d): ?>
        <tr>
          <td><?= date('d M y', strtotime($d['created_at'])) ?></td>
          <td class="text-green fw-bold"><?= format_currency($d['amount']) ?></td>
          <td><?= strtoupper($d['method']) ?></td>
          <td><span class="badge badge-<?= $d['status'] === 'approved' ? 'win' : ($d['status'] === 'rejected' ? 'loss' : 'pending') ?>"><?= strtoupper($d['status']) ?></span></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <div class="card__title mt-6">Withdrawal History</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Status</th></tr></thead>
      <tbody>
        <?php if (empty($withdrawals)): ?>
        <tr><td colspan="4" style="text-align:center;color:#6b6b8f;padding:20px;">No withdrawals yet.</td></tr>
        <?php else: foreach($withdrawals as $w): ?>
        <tr>
          <td><?= date('d M y', strtotime($w['created_at'])) ?></td>
          <td class="text-red fw-bold"><?= format_currency($w['amount']) ?></td>
          <td><?= strtoupper($w['method']) ?></td>
          <td><span class="badge badge-<?= $w['status'] === 'approved' ? 'win' : ($w['status'] === 'rejected' ? 'loss' : 'pending') ?>"><?= strtoupper($w['status']) ?></span></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
