<?php
define('BASE_PATH', '');
$page_title  = 'Referral';
$active_page = 'referral';
require_once 'config.php';
require_once 'includes/auth.php';
if (!is_logged_in()) redirect('login.php');
$user = get_current_user_data();
$db   = db_connect();

$refs = $db->prepare("SELECT username, created_at FROM users WHERE referred_by=? ORDER BY id DESC");
$refs->execute([$user['id']]);
$refs = $refs->fetchAll();
$ref_link = SITE_URL . 'register.php?ref=' . $user['referral_code'];
?>
<?php include 'includes/header.php'; ?>

<div class="section-title mb-4">Refer & <span>Earn</span></div>

<div class="card mb-6" style="background:linear-gradient(135deg,#1a0533,#0d2347);border-color:var(--gold);text-align:center;">
  <div style="font-size:11px;color:#6b6b8f;letter-spacing:1px;text-transform:uppercase;">Your Referral Code</div>
  <div style="font-family:'Rajdhani',sans-serif;font-size:40px;font-weight:700;color:var(--gold);letter-spacing:6px;margin:8px 0;"><?= $user['referral_code'] ?></div>
  <p style="color:#6b6b8f;font-size:12px;margin-bottom:14px;">Share this code and earn bonus when friends join!</p>
  <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;">
    <button class="btn btn--gold" onclick="copyRef()"><i class="fa fa-copy"></i> Copy Code</button>
    <button class="btn btn--outline" onclick="shareRef()"><i class="fa fa-share-alt"></i> Share Link</button>
  </div>
</div>

<div class="stats-grid mb-6">
  <div class="stat-card green">
    <div class="stat-card__icon">👥</div>
    <div class="stat-card__val"><?= count($refs) ?></div>
    <div class="stat-card__lbl">Total Referrals</div>
  </div>
  <div class="stat-card gold">
    <div class="stat-card__icon">💰</div>
    <div class="stat-card__val"><?= format_currency(count($refs) * 50) ?></div>
    <div class="stat-card__lbl">Bonus Earned</div>
  </div>
</div>

<div class="card">
  <div class="card__title">Referred Friends (<?= count($refs) ?>)</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Username</th><th>Joined</th><th>Bonus</th></tr></thead>
      <tbody>
        <?php if (empty($refs)): ?>
        <tr><td colspan="3" style="text-align:center;color:#6b6b8f;padding:20px;">No referrals yet. Share your code!</td></tr>
        <?php else: foreach($refs as $r): ?>
        <tr>
          <td><?= htmlspecialchars($r['username']) ?></td>
          <td><?= date('d M Y', strtotime($r['created_at'])) ?></td>
          <td class="text-green fw-bold"><?= format_currency(50) ?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
const refCode = '<?= $user['referral_code'] ?>';
const refLink = '<?= $ref_link ?>';
function copyRef() {
  navigator.clipboard.writeText(refCode).then(() => showAlert('Code copied!', 'success')).catch(() => {
    const el = document.createElement('textarea');
    el.value = refCode; document.body.appendChild(el); el.select();
    document.execCommand('copy'); document.body.removeChild(el);
    showAlert('Code copied!', 'success');
  });
}
function shareRef() {
  if (navigator.share) {
    navigator.share({ title: '<?= SITE_NAME ?>', text: 'Join me on <?= SITE_NAME ?>! Use code: ' + refCode, url: refLink });
  } else copyRef();
}
</script>

<?php include 'includes/footer.php'; ?>
