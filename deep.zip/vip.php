<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'VIP Club - 66Lottery';
$NAV_ACTIVE = 'profile';
$me = me(); $db = db_connect();
$wagered = $db->prepare("SELECT COALESCE(SUM(amount),0) FROM bets WHERE user_id=?"); $wagered->execute([$_SESSION['uid']]); $wagered=floatval($wagered->fetchColumn());
$vip_levels = [
  ['level'=>0,'name'=>'Bronze','min'=>0,'max'=>1000,'color'=>'#cd7f32','icon'=>'🥉','withdraw_limit'=>5000,'bonus'=>'0%'],
  ['level'=>1,'name'=>'Silver','min'=>1000,'max'=>5000,'color'=>'#c0c0c0','icon'=>'🥈','withdraw_limit'=>10000,'bonus'=>'1%'],
  ['level'=>2,'name'=>'Gold','min'=>5000,'max'=>20000,'color'=>'#f5c518','icon'=>'🥇','withdraw_limit'=>50000,'bonus'=>'2%'],
  ['level'=>3,'name'=>'Platinum','min'=>20000,'max'=>100000,'color'=>'#00b4d8','icon'=>'💎','withdraw_limit'=>200000,'bonus'=>'3%'],
  ['level'=>4,'name'=>'Diamond','min'=>100000,'max'=>500000,'color'=>'#9b6fe8','icon'=>'💠','withdraw_limit'=>500000,'bonus'=>'5%'],
  ['level'=>5,'name'=>'Crown','min'=>500000,'max'=>PHP_INT_MAX,'color'=>'#f5c518','icon'=>'👑','withdraw_limit'=>999999,'bonus'=>'8%'],
];
$cur = $vip_levels[$me['vip_level']] ?? $vip_levels[0];
$next = $vip_levels[min($me['vip_level']+1,5)];
$progress = $cur['max']>$cur['min'] ? min(100,round(($wagered-$cur['min'])/($cur['max']-$cur['min'])*100)) : 100;
include 'includes/header.php';
?>
<div class="wingo-header">
  <div style="display:flex;align-items:center;gap:12px;">
    <a href="/profile.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">VIP Club</div>
  </div>
</div>
<div class="vip-card">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;">
    <div>
      <div style="font-size:12px;color:var(--muted);">Current Level</div>
      <div class="vip-level"><?= $cur['icon'] ?> VIP <?= $cur['level'] ?> - <?= $cur['name'] ?></div>
    </div>
    <div style="font-size:36px;"><?= $cur['icon'] ?></div>
  </div>
  <div style="font-size:11px;color:var(--muted);margin-top:10px;">Progress to <?= $next['icon'] ?> <?= $next['name'] ?></div>
  <div class="vip-bar"><div class="vip-bar-fill" style="width:<?= $progress ?>%;"></div></div>
  <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--muted);">
    <span><?= money($wagered) ?> wagered</span>
    <span>Need <?= money($next['min']) ?></span>
  </div>
  <div class="vip-perks">
    <div class="vip-perk"><div class="vip-perk-val"><?= money($cur['withdraw_limit']) ?></div><div class="vip-perk-label">Daily Withdraw Limit</div></div>
    <div class="vip-perk"><div class="vip-perk-val"><?= $cur['bonus'] ?></div><div class="vip-perk-label">Cashback Bonus</div></div>
  </div>
</div>

<div class="section">
  <div class="section-title" style="margin-bottom:12px;">All VIP Levels</div>
  <?php foreach($vip_levels as $v): ?>
  <div style="background:var(--card);border:2px solid <?= $v['level']==$me['vip_level']?$v['color']:'var(--border)' ?>;border-radius:12px;padding:14px;margin-bottom:8px;display:flex;align-items:center;gap:12px;">
    <div style="font-size:28px;"><?= $v['icon'] ?></div>
    <div style="flex:1;">
      <div style="font-size:13px;font-weight:700;color:<?= $v['color'] ?>;">VIP <?= $v['level'] ?> · <?= $v['name'] ?></div>
      <div style="font-size:11px;color:var(--muted);margin-top:3px;">Wager <?= money($v['min']) ?> · <?= $v['bonus'] ?> cashback</div>
    </div>
    <?php if($v['level']==$me['vip_level']): ?><div style="font-size:11px;background:<?= $v['color'] ?>;color:#000;padding:3px 8px;border-radius:99px;font-weight:700;">CURRENT</div><?php elseif($v['level']<$me['vip_level']): ?><div style="font-size:16px;">✅</div><?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>
<?php include 'includes/footer.php'; ?>
