<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'Invite - 66Lottery';
$NAV_ACTIVE = 'invite';
$me = me(); $db = db_connect();
$refs = $db->prepare("SELECT id,username,created_at FROM users WHERE referred_by=?");
$refs->execute([$_SESSION['uid']]); $refs=$refs->fetchAll();
$ref_link = 'https://yourdomain.com/login.php?ref='.$me['referral_code'];
include 'includes/header.php';
?>
<div class="wingo-header">
  <div style="display:flex;align-items:center;gap:12px;">
    <a href="/profile.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">Invite Friends</div>
  </div>
</div>

<!-- HERO BANNER -->
<div style="background:linear-gradient(135deg,#005c35,#003820);margin:12px;border-radius:16px;padding:20px;text-align:center;border:1px solid rgba(0,185,107,.3);">
  <div style="font-size:40px;margin-bottom:8px;">🎉</div>
  <div style="font-size:18px;font-weight:800;color:var(--green);">Earn ₹50 Per Referral!</div>
  <div style="font-size:12px;color:var(--muted);margin-top:6px;">Invite friends and earn bonus when they register and play</div>
</div>

<!-- REF STATS -->
<div class="ref-stats">
  <div class="ref-stat">
    <div class="ref-stat-val"><?= count($refs) ?></div>
    <div class="ref-stat-label">Friends</div>
  </div>
  <div class="ref-stat">
    <div class="ref-stat-val"><?= money(count($refs)*50) ?></div>
    <div class="ref-stat-label">Earned</div>
  </div>
  <div class="ref-stat">
    <div class="ref-stat-val">₹50</div>
    <div class="ref-stat-label">Per Invite</div>
  </div>
</div>

<!-- REF CODE -->
<div class="ref-card">
  <div style="font-size:12px;color:var(--muted);">Your Referral Code</div>
  <div class="ref-code"><?= $me['referral_code'] ?></div>
  <div class="ref-link"><?= $ref_link ?></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px;">
    <button class="ref-copy-btn" onclick="copyText('<?= $me['referral_code'] ?>')">📋 Copy Code</button>
    <button class="ref-copy-btn" style="background:var(--violet);" onclick="shareLink()">📤 Share Link</button>
  </div>
</div>

<!-- FRIENDS LIST -->
<div class="section">
  <div class="section-title" style="margin-bottom:10px;">Invited Friends (<?= count($refs) ?>)</div>
  <?php if(empty($refs)): ?>
  <div class="empty-state"><div class="empty-icon">👥</div><div>No friends yet. Share your code!</div></div>
  <?php else: ?>
  <div class="hist-table">
    <?php foreach($refs as $r): ?>
    <div class="hist-row">
      <div style="font-size:24px;">👤</div>
      <div class="hist-period" style="flex:1;"><div class="hist-period-no"><?= htmlspecialchars($r['username']) ?></div><div class="hist-period-time"><?= date('d M Y',strtotime($r['created_at'])) ?></div></div>
      <div style="color:var(--green);font-weight:700;">+₹50.00</div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- STEPS -->
<div class="section">
  <div class="section-title" style="margin-bottom:10px;">How It Works</div>
  <div style="background:var(--card);border:1px solid var(--border);border-radius:12px;padding:16px;">
    <?php $steps=[['1','Share your referral code with friends','var(--green)'],['2','Friend registers using your code','var(--violet)'],['3','You get ₹50 bonus instantly!','var(--gold)']];
    foreach($steps as [$n,$t,$c]): ?>
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:<?= $n<3?'14':'0' ?>px;">
      <div style="width:32px;height:32px;background:<?= $c ?>;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;color:#000;flex-shrink:0;"><?= $n ?></div>
      <div style="font-size:13px;"><?= $t ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<script>
function shareLink() {
  const link = '<?= $ref_link ?>';
  const code = '<?= $me['referral_code'] ?>';
  if (navigator.share) {
    navigator.share({ title: '66Lottery', text: '🎰 Join 66Lottery! Use code: '+code+' and get bonus!', url: link });
  } else { copyText(link); }
}
</script>
<?php include 'includes/footer.php'; ?>
