<?php
define('SITE_NAME', '66Lottery');
define('SITE_TAGLINE', 'Trusted • Safe • Fast');
define('CURRENCY', '₹');
define('DB_HOST', 'localhost');
define('DB_NAME', 'lottery_db');
define('DB_USER', 'lottery_user');
define('DB_PASS', 'Lottery@2024#Secure');
define('DB_CHARSET', 'utf8mb4');
define('MIN_BET', 10);
define('MAX_BET', 100000);
date_default_timezone_set('Asia/Kolkata');
error_reporting(0);
ini_set('display_errors', 0);

function db_connect() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            die(json_encode(['error' => $e->getMessage()]));
        }
    }
    return $pdo;
}

session_name('lottery66_sess');
if (session_status() === PHP_SESSION_NONE) session_start();

function is_logged_in() { return !empty($_SESSION['uid']); }
function me() {
    if (!is_logged_in()) return null;
    $s = db_connect()->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
    $s->execute([$_SESSION['uid']]);
    return $s->fetch();
}
function go($url) { header("Location:$url"); exit; }
function clean($d) { return htmlspecialchars(strip_tags(trim($d))); }
function money($n) { return CURRENCY.number_format($n,2); }
function require_login() { if(!is_logged_in()) go('/login.php'); }
