<?php
// ============================================================
//  66LOTTERY DASHBOARD - CONFIG FILE
//  Edit this file to set your site/database settings
// ============================================================

// ---- SITE SETTINGS ----
define('SITE_NAME',    '66Lottery');
define('SITE_TAGLINE', 'Fair & Safe • Fast Withdrawal');
define('SITE_URL',     'https://www.66lottery.vip/');
define('SITE_LOGO',    'assets/img/logo.png');
define('CURRENCY',     '₹');
define('VERSION',      '1.0.0');

// ---- DATABASE SETTINGS ----
define('DB_HOST',     'localhost');
define('DB_NAME',     'lottery_db');
define('DB_USER',     'root');
define('DB_PASS',     '');
define('DB_CHARSET',  'utf8mb4');

// ---- SESSION & SECURITY ----
define('SESSION_NAME',    'lottery_session');
define('SESSION_LIFETIME', 3600);   // 1 hour
define('SECRET_KEY',      'change_this_to_random_secret_key_66lottery');

// ---- GAME SETTINGS ----
define('MIN_BET',    10);    // Minimum bet amount (₹)
define('MAX_BET',    10000); // Maximum bet amount (₹)
define('JACKPOT_AMT', 500000);

// ---- TIMEZONE ----
date_default_timezone_set('Asia/Kolkata');

// ---- ERROR REPORTING (set to 0 in production) ----
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================================
//  DATABASE CONNECTION
// ============================================================
function db_connect() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// ============================================================
//  SESSION START
// ============================================================
session_name(SESSION_NAME);
session_start();

// ============================================================
//  HELPER FUNCTIONS
// ============================================================

function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function format_currency($amount) {
    return CURRENCY . number_format($amount, 2);
}

function generate_token() {
    return bin2hex(random_bytes(32));
}

function time_ago($datetime) {
    $now  = new DateTime();
    $ago  = new DateTime($datetime);
    $diff = $now->diff($ago);
    if ($diff->i < 1)   return 'Just now';
    if ($diff->h < 1)   return $diff->i . 'm ago';
    if ($diff->d < 1)   return $diff->h . 'h ago';
    return $diff->d . 'd ago';
}
?>
