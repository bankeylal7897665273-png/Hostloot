<?php
define('BASE_PATH', '');
$page_title  = 'Bet History';
$active_page = 'history';
require_once 'config.php';
require_once 'includes/auth.php';
if (!is_logged_in()) redirect('login.php');
$user = get_current_user_data();
$db   = db_connect();

$page   = max(1, intval($_GET['p'] ?? 1));
$limit  = 20;
$offset = ($page - 1) * $limit;

$total_stmt = $db->prepare("SELECT COUNT(*) FROM bets WHERE user_id=?");
$total_stmt->execute([$user['id']]);
$total = $total_stmt->fetchColumn();
$pages = ceil($total / $limit);

$bets = $db->prepare("SELECT b.*, g.name as game_name FROM bets b JOIN games g ON g.id=b.game_id WHERE b.user_id=? ORDER BY b.id DESC LIMIT ? OFFSET ?");
$bets->execute([$user['id'], $limit, $offset]);
$bets = $bets->fetchAll();
?>
<?php include 'includes/header.php'; ?>

<div class="section-title mb-4">Bet <span>History</span></div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Date</th><th>Game</th><th>Bet</th><th>Win</th><th>Result</th></tr>
      </thead>
      <tbody>
        <?php if (empty($bets)): ?>
        <tr><td colspan="5" style="text-align:center;color:#6b6b8f;padding:30px;">No betting history yet.<br/><a href="index.php" style="color:var(--purple-lt)">Start Playing →</a></td></tr>
        <?php else: foreach($bets as $b): ?>
        <tr>
          <td><?= date('d M y H:i', strtotime($b['created_at'])) ?></td>
          <td><?= htmlspecialchars($b['game_name']) ?></td>
          <td class="text-muted"><?= format_currency($b['bet_amount']) ?></td>
          <td class="<?= $b['result'] === 'win' ? 'text-green' : 'text-muted' ?> fw-bold"><?= format_currency($b['win_amount']) ?></td>
          <td><span class="badge badge-<?= $b['result'] === 'win' ? 'win' : ($b['result'] === 'loss' ? 'loss' : 'pending') ?>"><?= strtoupper($b['result']) ?></span></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($pages > 1): ?>
  <div style="display:flex;gap:6px;justify-content:center;margin-top:16px;flex-wrap:wrap;">
    <?php for($i=1; $i<=$pages; $i++): ?>
    <a href="?p=<?= $i ?>" class="btn <?= $i == $page ? 'btn--primary' : 'btn--outline' ?>" style="padding:6px 12px;font-size:13px;"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
