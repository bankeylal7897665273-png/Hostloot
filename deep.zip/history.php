<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'Bet History - 66Lottery';
$NAV_ACTIVE = 'profile';
$me = me(); $db = db_connect();
$page = max(1,intval($_GET['p']??1));
$limit = 20; $offset = ($page-1)*$limit;
$total = $db->prepare("SELECT COUNT(*) FROM bets WHERE user_id=?"); $total->execute([$_SESSION['uid']]); $total=$total->fetchColumn();
$pages = max(1,ceil($total/$limit));
$bets = $db->prepare("SELECT * FROM bets WHERE user_id=? ORDER BY id DESC LIMIT ? OFFSET ?");
$bets->execute([$_SESSION['uid'],$limit,$offset]); $bets=$bets->fetchAll();
include 'includes/header.php';
?>
<div class="wingo-header">
  <div style="display:flex;align-items:center;gap:12px;">
    <a href="/profile.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">Bet History</div>
  </div>
</div>
<div style="display:flex;padding:10px 12px;gap:6px;overflow-x:auto;">
  <div class="page-tab active">All</div>
  <div class="page-tab">Win Go</div>
  <div class="page-tab">K3</div>
  <div class="page-tab">5D</div>
  <div class="page-tab">Trx</div>
</div>
<div class="section">
<?php if(empty($bets)): ?>
<div class="empty-state"><div class="empty-icon">📋</div><div>No bets yet</div><a href="/index.php" style="color:var(--green);font-size:13px;margin-top:8px;display:block;">Start Playing →</a></div>
<?php else: foreach($bets as $b): ?>
<div class="mybet-row">
  <div class="mybet-top">
    <div class="mybet-game">🎮 <?= strtoupper($b['game']) ?> · <?= ucfirst($b['bet_type']) ?></div>
    <div class="mybet-status status-<?= $b['status'] ?>"><?= strtoupper($b['status']) ?></div>
  </div>
  <div class="mybet-row-mid">
    <div>Bet: <b><?= ucfirst($b['bet_value']) ?></b></div>
    <div>Period: <b><?= $b['period_no'] ?></b></div>
    <div><?= date('d M H:i',strtotime($b['created_at'])) ?></div>
  </div>
  <div class="flex-between" style="margin-top:6px;">
    <div style="font-size:12px;color:var(--muted);">Bet Amount: <?= money($b['amount']) ?></div>
    <div class="mybet-amount <?= $b['status']==='win'?'win':($b['status']==='loss'?'loss':'') ?>" style="font-size:15px;">
      <?= $b['status']==='win'?'+'.money($b['win_amount']):($b['status']==='loss'?'-'.money($b['amount']):'Pending') ?>
    </div>
  </div>
</div>
<?php endforeach; endif; ?>
<?php if($pages>1): ?>
<div style="display:flex;gap:6px;justify-content:center;margin-top:12px;flex-wrap:wrap;">
  <?php for($i=1;$i<=$pages;$i++): ?>
  <a href="?p=<?= $i ?>" style="padding:6px 12px;border-radius:8px;font-size:12px;font-weight:700;<?= $i==$page?'background:var(--green);color:#fff;':'background:var(--card);color:var(--muted);border:1px solid var(--border);' ?>"><?= $i ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
