<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'Withdraw - 66Lottery';
$NAV_ACTIVE = 'profile';
$me = me(); $db = db_connect();
$msg=''; $msg_type='success';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $amount  = floatval($_POST['amount']??0);
    $method  = clean($_POST['method']??'');
    $account = clean($_POST['account']??'');
    if ($amount < 200) { $msg='Minimum withdrawal is ₹200.'; $msg_type='error'; }
    elseif ($amount > $me['balance']) { $msg='Insufficient balance.'; $msg_type='error'; }
    elseif (!$method||!$account) { $msg='Please fill all fields.'; $msg_type='error'; }
    else {
        $db->prepare("UPDATE users SET balance=balance-? WHERE id=?")->execute([$amount,$_SESSION['uid']]);
        $db->prepare("INSERT INTO withdrawals(user_id,amount,method,account_info) VALUES(?,?,?,?)")->execute([$_SESSION['uid'],$amount,$method,$account]);
        $msg='✅ Withdrawal request submitted! Processing within 24 hours.';
        $me = me();
    }
}
$withs = $db->prepare("SELECT * FROM withdrawals WHERE user_id=? ORDER BY id DESC LIMIT 10");
$withs->execute([$_SESSION['uid']]); $withs=$withs->fetchAll();
include 'includes/header.php';
?>
<div class="wingo-header">
  <div style="display:flex;align-items:center;gap:12px;">
    <a href="/profile.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">Withdraw</div>
  </div>
</div>

<div class="wallet-card">
  <div class="wallet-label">Available Balance</div>
  <div class="wallet-amount balance-val"><?= money($me['balance']) ?></div>
  <div style="font-size:12px;color:rgba(255,255,255,.7);">Total Withdrawn: <?= money($me['total_withdraw']) ?></div>
</div>

<div style="display:flex;padding:0 12px 12px;gap:6px;">
  <div class="page-tab active" id="wTabBtn" onclick="showWTab('form')">Withdraw</div>
  <div class="page-tab" id="wHistBtn" onclick="showWTab('hist')">History</div>
</div>

<div id="wFormTab">
  <?php if($msg): ?>
  <div style="margin:0 12px 12px;padding:12px;border-radius:10px;font-size:13px;background:rgba(<?= $msg_type==='error'?'240,83,43':'0,185,107' ?>,.12);border:1px solid rgba(<?= $msg_type==='error'?'240,83,43':'0,185,107' ?>,.3);color:<?= $msg_type==='error'?'var(--red)':'var(--green)' ?>;"><?= $msg ?></div>
  <?php endif; ?>
  <div class="section">
    <form method="POST">
      <div class="form-group">
        <label class="form-label">💰 Amount (Min ₹200)</label>
        <div class="amount-grid">
          <?php foreach([200,500,1000,2000,5000,10000] as $a): ?>
          <div class="agrid-btn" data-val="<?= $a ?>" onclick="document.getElementById('wAmtInp').value=<?= $a ?>;this.closest('.amount-grid').querySelectorAll('.agrid-btn').forEach(b=>b.classList.remove('active'));this.classList.add('active');">₹<?= number_format($a) ?></div>
          <?php endforeach; ?>
        </div>
        <input class="form-input" id="wAmtInp" type="number" name="amount" placeholder="Enter amount" min="200" max="<?= $me['balance'] ?>"/>
      </div>
      <div class="form-group">
        <label class="form-label">🏦 Withdrawal Method</label>
        <select class="form-select" name="method" id="wMethodSel" onchange="toggleWMethod()">
          <option value="">Select method</option>
          <option value="upi">UPI</option>
          <option value="bank">Bank Transfer</option>
          <option value="crypto_usdt">Crypto (USDT)</option>
        </select>
      </div>
      <div class="form-group" id="upiField" style="display:none;">
        <label class="form-label">📱 UPI ID</label>
        <input class="form-input" type="text" name="account" placeholder="yourname@upi" id="upiInp"/>
      </div>
      <div id="bankFields" style="display:none;">
        <div class="form-group">
          <label class="form-label">👤 Account Holder Name</label>
          <input class="form-input" type="text" placeholder="Full name"/>
        </div>
        <div class="form-group">
          <label class="form-label">🏦 Account Number</label>
          <input class="form-input" type="text" name="account" placeholder="Enter account number"/>
        </div>
        <div class="form-group">
          <label class="form-label">🔢 IFSC Code</label>
          <input class="form-input" type="text" placeholder="IFSC code"/>
        </div>
      </div>
      <div class="form-group" id="cryptoField" style="display:none;">
        <label class="form-label">💎 USDT Wallet (TRC20)</label>
        <input class="form-input" type="text" name="account" placeholder="TRC20 wallet address" id="cryptoInp"/>
      </div>
      <div style="background:rgba(245,197,24,.1);border:1px solid rgba(245,197,24,.3);border-radius:10px;padding:12px;margin-bottom:14px;font-size:12px;color:var(--gold);">
        ⚠️ Min: ₹200 · Processing: 1-24 hours · Verify your details carefully
      </div>
      <button type="submit" class="submit-btn red-btn-bg">Withdraw Now →</button>
    </form>
  </div>
</div>

<div id="wHistTab" style="display:none;">
  <div class="section">
    <?php if(empty($withs)): ?>
    <div class="empty-state"><div class="empty-icon">🏦</div><div>No withdrawals yet</div></div>
    <?php else: foreach($withs as $w): ?>
    <div class="mybet-row">
      <div class="mybet-top">
        <div class="mybet-game">🏦 <?= strtoupper($w['method']) ?></div>
        <div class="mybet-status status-<?= $w['status']==='approved'?'win':($w['status']==='rejected'?'loss':'pending') ?>"><?= strtoupper($w['status']) ?></div>
      </div>
      <div class="mybet-row-mid"><div><?= htmlspecialchars(substr($w['account_info'],0,20)) ?>...</div><div><?= date('d M H:i',strtotime($w['created_at'])) ?></div></div>
      <div class="mybet-amount loss">-<?= money($w['amount']) ?></div>
    </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<script>
function toggleWMethod() {
  const v = document.getElementById('wMethodSel').value;
  document.getElementById('upiField').style.display = v==='upi'?'block':'none';
  document.getElementById('bankFields').style.display = v==='bank'?'block':'none';
  document.getElementById('cryptoField').style.display = v==='crypto_usdt'?'block':'none';
}
function showWTab(t) {
  document.getElementById('wFormTab').style.display = t==='form'?'block':'none';
  document.getElementById('wHistTab').style.display = t==='hist'?'block':'none';
  document.getElementById('wTabBtn').classList.toggle('active',t==='form');
  document.getElementById('wHistBtn').classList.toggle('active',t==='hist');
}
</script>
<?php include 'includes/footer.php'; ?>
