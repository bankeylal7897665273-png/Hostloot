<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = '5D Lotre - 66Lottery';
$NAV_ACTIVE = 'home';
$me = me();
$now = time(); $secs = 60;
$rem = $secs - ($now % $secs);
$period_no = date('Ymd').str_pad(floor(($now%86400)/$secs),4,'0',STR_PAD_LEFT);
include 'includes/header.php';
?>
<div class="wingo-header">
  <div style="display:flex;align-items:center;justify-content:space-between;">
    <a href="/index.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">5D Lotre</div>
    <div style="font-size:14px;">🔢</div>
  </div>
</div>
<div class="wingo-tabs" style="padding:8px 12px 10px;">
  <button class="wingo-tab active">1 Min</button>
  <button class="wingo-tab">3 Min</button>
  <button class="wingo-tab">5 Min</button>
</div>
<div class="period-box">
  <div>
    <div class="period-label">Period</div>
    <div class="period-no"><?= $period_no ?></div>
    <div style="font-size:12px;color:var(--muted);margin-top:8px;">Count Down</div>
    <div id="countTimer" class="timer-val"><?= sprintf('%02d:%02d',floor($rem/60),$rem%60) ?></div>
  </div>
  <div style="display:flex;gap:6px;">
    <?php for($i=0;$i<5;$i++): ?>
    <div style="width:40px;height:50px;background:var(--card2);border:2px solid var(--border);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;color:var(--green);">?</div>
    <?php endfor; ?>
  </div>
</div>

<div class="section">
  <div class="section-title" style="margin-bottom:10px;">Bet on Digits</div>
  <div style="background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden;">
    <?php $positions = ['A','B','C','D','E']; foreach($positions as $pos): ?>
    <div style="padding:12px;border-bottom:1px solid var(--border);">
      <div style="font-size:12px;font-weight:700;color:var(--muted);margin-bottom:8px;">Digit <?= $pos ?></div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;">
        <?php for($n=0;$n<=9;$n++):
          $cls = $n==0?'violet':($n%2==0?'red':'green');
        ?>
        <div onclick="openBetModal('5d_digit','<?= $pos.$n ?>','Digit <?= $pos ?>=<?= $n ?>','<?= $cls ?>')"
             style="width:36px;height:36px;border-radius:50%;background:var(--<?= $cls ?>);display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;cursor:pointer;"><?= $n ?></div>
        <?php endfor; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <div style="padding:12px;">
      <div style="font-size:12px;font-weight:700;color:var(--muted);margin-bottom:8px;">Total Sum</div>
      <div class="size-btns" style="padding:0;">
        <div class="sbtn big-btn" onclick="openBetModal('5d_sum','big','Sum Big','red')"><div>Big (23-45)</div><div style="font-size:11px;">Win 2x</div></div>
        <div class="sbtn small-btn" onclick="openBetModal('5d_sum','small','Sum Small','green')"><div>Small (0-22)</div><div style="font-size:11px;">Win 2x</div></div>
      </div>
    </div>
  </div>
</div>

<!-- BET MODAL -->
<div class="modal-overlay" id="betModal">
  <div class="modal-box">
    <div class="modal-head"><div class="modal-title">5D Lotre · 1 Min</div><div class="modal-close" onclick="closeModal('betModal')">✕</div></div>
    <div class="modal-body">
      <div class="modal-sel"><div class="rball sel-ball green" id="selBall"></div><div><div class="sel-label" id="selLabel">Select</div></div></div>
      <div class="amount-btns">
        <div class="amt-btn" data-val="10">₹10</div><div class="amt-btn" data-val="50">₹50</div>
        <div class="amt-btn" data-val="100">₹100</div><div class="amt-btn" data-val="500">₹500</div>
        <div class="amt-btn" data-val="1000">₹1K</div><div class="amt-btn" data-val="x5">×5</div>
      </div>
      <input type="number" id="betAmountInp" class="amt-input" value="10" min="10" oninput="updateModalInfo()"/>
      <div class="modal-info">
        <div class="modal-info-row"><span>Amount</span><span id="infoAmt">₹10.00</span></div>
        <div class="modal-info-row"><span>Fee (2%)</span><span id="infoFee">₹0.20</span></div>
        <div class="modal-info-row"><span>After Fee</span><span id="infoAfter">₹9.80</span></div>
      </div>
      <div style="font-size:11px;color:var(--muted);margin-bottom:12px;">Balance: <span class="balance-val"><?= money($me['balance']) ?></span></div>
      <button class="modal-confirm" onclick="placeBet('5d')">✅ Confirm Bet</button>
    </div>
  </div>
</div>
<script>startTimer(<?= $rem ?>,'countTimer',()=>location.reload());</script>
<?php include 'includes/footer.php'; ?>
