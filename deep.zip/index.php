<?php
define('BASE_PATH', '');
$page_title  = 'Home';
$active_page = 'home';
require_once 'config.php';
require_once 'includes/auth.php';

$user = get_current_user_data();

// Fetch featured games
$db    = db_connect();
$games = $db->query("SELECT * FROM games WHERE is_active=1 ORDER BY is_featured DESC LIMIT 8")->fetchAll();

// Stats for logged in user
$stats = ['bets' => 0, 'won' => '0.00', 'deposits' => '0.00'];
if ($user) {
    $s = $db->prepare("SELECT COUNT(*) as bets, COALESCE(SUM(win_amount),0) as won FROM bets WHERE user_id=?");
    $s->execute([$user['id']]);
    $row = $s->fetch();
    $stats['bets'] = $row['bets'];
    $stats['won']  = number_format($row['won'], 2);
}
?>
<?php include 'includes/header.php'; ?>

<!-- MARQUEE NOTICE -->
<div class="marquee-bar">
  <i class="fa fa-bullhorn"></i>
  <div class="marquee-inner">
    <span>🎉 Welcome to <?= SITE_NAME ?>! Fast withdrawals • Safe & Secure • 24/7 Support • Play responsibly 🎰</span>
  </div>
</div>

<!-- JACKPOT BANNER -->
<div class="jackpot-banner">
  <div class="jackpot-label">Current Jackpot</div>
  <div class="jackpot-amount"><?= format_currency(JACKPOT_AMT) ?></div>
  <p style="color:#6b6b8f;font-size:12px;margin-top:6px;position:relative;z-index:1;">Updated every draw round</p>
</div>

<!-- STATS ROW -->
<?php if ($user): ?>
<div class="stats-grid">
  <div class="stat-card purple">
    <div class="stat-card__icon">💰</div>
    <div class="stat-card__val"><?= format_currency($user['balance']) ?></div>
    <div class="stat-card__lbl">Balance</div>
  </div>
  <div class="stat-card green">
    <div class="stat-card__icon">🏆</div>
    <div class="stat-card__val"><?= CURRENCY . $stats['won'] ?></div>
    <div class="stat-card__lbl">Total Won</div>
  </div>
  <div class="stat-card gold">
    <div class="stat-card__icon">🎲</div>
    <div class="stat-card__val"><?= $stats['bets'] ?></div>
    <div class="stat-card__lbl">Total Bets</div>
  </div>
  <div class="stat-card red">
    <div class="stat-card__icon">⭐</div>
    <div class="stat-card__val"><?= $user['referral_code'] ?? '---' ?></div>
    <div class="stat-card__lbl">Referral Code</div>
  </div>
</div>
<?php else: ?>
<div class="card mb-6" style="text-align:center;padding:30px;">
  <p style="font-size:16px;margin-bottom:14px;">Join <?= SITE_NAME ?> and start winning today!</p>
  <div class="d-flex gap-2" style="justify-content:center;">
    <a href="register.php" class="btn btn--primary btn--lg">Register Now</a>
    <a href="login.php" class="btn btn--outline btn--lg">Login</a>
  </div>
</div>
<?php endif; ?>

<!-- FEATURED GAMES -->
<div class="section-header">
  <div class="section-title">Featured <span>Games</span></div>
  <a href="games.php" style="font-size:12px;color:#9d5cf5;text-decoration:none;">View All →</a>
</div>
<div class="games-grid">
  <?php
  $icons = ['🟢','🎲','🔢','💎','🎯','🪙','⚡','🌟'];
  foreach ($games as $i => $g):
  ?>
  <a href="<?= htmlspecialchars($g['slug']) ?>.php" class="game-card">
    <div class="game-card__thumb">
      <?= $icons[$i % count($icons)] ?>
      <?php if ($g['is_featured']): ?><div class="game-card__badge">HOT</div><?php endif; ?>
    </div>
    <div class="game-card__body">
      <div class="game-card__name"><?= htmlspecialchars($g['name']) ?></div>
      <div class="game-card__info">Min Bet: <?= format_currency($g['min_bet']) ?> • RTP <?= $g['rtp'] ?>%</div>
      <div class="game-card__btn">
        <div class="btn btn--primary" style="font-size:12px;padding:6px 14px;margin-top:8px;display:inline-flex;">Play Now</div>
      </div>
    </div>
  </a>
  <?php endforeach; ?>
</div>

<!-- QUICK ACTIONS -->
<div class="section-title mb-4">Quick <span>Actions</span></div>
<div class="stats-grid">
  <a href="wallet.php?tab=deposit" class="stat-card green" style="text-decoration:none;cursor:pointer;text-align:center;">
    <div class="stat-card__icon">💳</div>
    <div class="stat-card__val" style="font-size:16px;">Deposit</div>
  </a>
  <a href="wallet.php?tab=withdraw" class="stat-card purple" style="text-decoration:none;cursor:pointer;text-align:center;">
    <div class="stat-card__icon">🏦</div>
    <div class="stat-card__val" style="font-size:16px;">Withdraw</div>
  </a>
  <a href="referral.php" class="stat-card gold" style="text-decoration:none;cursor:pointer;text-align:center;">
    <div class="stat-card__icon">👥</div>
    <div class="stat-card__val" style="font-size:16px;">Refer</div>
  </a>
  <a href="history.php" class="stat-card red" style="text-decoration:none;cursor:pointer;text-align:center;">
    <div class="stat-card__icon">📋</div>
    <div class="stat-card__val" style="font-size:16px;">History</div>
  </a>
</div>

<?php include 'includes/footer.php'; ?>
