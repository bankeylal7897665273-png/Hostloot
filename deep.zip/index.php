<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
$PAGE_TITLE = '66Lottery - Home';
$NAV_ACTIVE = 'home';
$db = db_connect();
$notice = $db->query("SELECT content FROM notices WHERE is_active=1 ORDER BY id DESC LIMIT 1")->fetchColumn();
$notice = $notice ?: '🎉 Welcome to 66Lottery! Fastest withdrawal • Safe & Secure • 24/7 Support!';
include 'includes/header.php';
?>

<!-- BANNER -->
<div class="banner">
  <div class="banner-inner">
    <div class="banner-title">₹5,00,000</div>
    <div class="banner-sub">🎉 Today's Jackpot Prize Pool</div>
    <div style="margin-top:10px;">
      <a href="/wingo.php" style="background:#ffed4a;color:#000;padding:8px 20px;border-radius:99px;font-size:13px;font-weight:800;">Play Now →</a>
    </div>
  </div>
  <div class="banner-badge">🔥 HOT</div>
  <div class="banner-dots">
    <div class="banner-dot active"></div>
    <div class="banner-dot"></div>
    <div class="banner-dot"></div>
  </div>
</div>

<!-- NOTICE -->
<div class="notice-bar">
  <div class="notice-icon">📢</div>
  <div class="notice-scroll"><span><?= htmlspecialchars($notice) ?></span></div>
</div>

<!-- GAME MENU ICONS -->
<div class="section">
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:4px;">
    <a href="/recharge.php" style="text-align:center;">
      <div style="background:linear-gradient(135deg,#00c97a,#008c54);width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:24px;margin:0 auto 5px;">💰</div>
      <div style="font-size:11px;font-weight:600;">Recharge</div>
    </a>
    <a href="/withdraw.php" style="text-align:center;">
      <div style="background:linear-gradient(135deg,#f5673a,#c0340f);width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:24px;margin:0 auto 5px;">🏦</div>
      <div style="font-size:11px;font-weight:600;">Withdraw</div>
    </a>
    <a href="/gift.php" style="text-align:center;">
      <div style="background:linear-gradient(135deg,#f5c518,#e07e00);width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:24px;margin:0 auto 5px;">🎁</div>
      <div style="font-size:11px;font-weight:600;">Gift Card</div>
    </a>
    <a href="/invite.php" style="text-align:center;">
      <div style="background:linear-gradient(135deg,#9b6fe8,#5c35a0);width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:24px;margin:0 auto 5px;">👥</div>
      <div style="font-size:11px;font-weight:600;">Invite</div>
    </a>
  </div>
</div>

<!-- WIN GO SECTION -->
<div class="section">
  <div class="section-head">
    <div class="section-title">Lottery Games</div>
    <a href="/wingo.php" class="see-all">See All</a>
  </div>
  <div class="game-grid">
    <a href="/wingo.php?t=1min" class="game-card">
      <div class="game-thumb g1">🟢
        <div class="game-hot">HOT</div>
      </div>
      <div class="game-info">
        <div class="game-name">Win Go</div>
        <div class="game-desc">1 Min • Color</div>
      </div>
    </a>
    <a href="/wingo.php?t=3min" class="game-card">
      <div class="game-thumb g1">🔵</div>
      <div class="game-info">
        <div class="game-name">Win Go</div>
        <div class="game-desc">3 Min • Color</div>
      </div>
    </a>
    <a href="/wingo.php?t=5min" class="game-card">
      <div class="game-thumb g1">🟡</div>
      <div class="game-info">
        <div class="game-name">Win Go</div>
        <div class="game-desc">5 Min • Color</div>
      </div>
    </a>
    <a href="/k3.php" class="game-card">
      <div class="game-thumb g2">🎲
        <div class="game-hot">NEW</div>
      </div>
      <div class="game-info">
        <div class="game-name">K3 Lotre</div>
        <div class="game-desc">1 Min • Dice</div>
      </div>
    </a>
    <a href="/5d.php" class="game-card">
      <div class="game-thumb g3">🔢</div>
      <div class="game-info">
        <div class="game-name">5D Lotre</div>
        <div class="game-desc">1 Min • Number</div>
      </div>
    </a>
    <a href="/trx.php" class="game-card">
      <div class="game-thumb g4">💎</div>
      <div class="game-info">
        <div class="game-name">Trx Win Go</div>
        <div class="game-desc">1 Min • TRX</div>
      </div>
    </a>
  </div>
</div>

<!-- RECENT WINNERS -->
<div class="section">
  <div class="section-head">
    <div class="section-title">Recent Winners</div>
  </div>
  <div class="hist-table">
    <?php
    $winners = [
      ['Raj***','Win Go','₹12,400','🟢'],
      ['Pri***','K3 Lotre','₹8,200','🎲'],
      ['Sam***','Trx Win Go','₹5,500','💎'],
      ['Anu***','Win Go','₹22,000','🟢'],
      ['Vik***','5D Lotre','₹3,800','🔢'],
    ];
    foreach($winners as $w): ?>
    <div class="hist-row">
      <div style="font-size:20px;"><?= $w[3] ?></div>
      <div class="hist-period" style="flex:1;">
        <div class="hist-period-no"><?= $w[0] ?></div>
        <div class="hist-period-time"><?= $w[1] ?></div>
      </div>
      <div style="font-size:14px;font-weight:800;color:var(--green);"><?= $w[2] ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
