<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'K3 Lotre - 66Lottery';
$NAV_ACTIVE = 'home';
$db = db_connect();
$results = $db->query("SELECT * FROM k3_periods WHERE status='closed' ORDER BY id DESC LIMIT 20")->fetchAll();
$mybets = $db->prepare("SELECT * FROM bets WHERE user_id=? AND game='k3' ORDER BY id DESC LIMIT 20");
$mybets->execute([$_SESSION['uid']]); $mybets=$mybets->fetchAll();
$me = me();
// Current period
$now = time(); $secs = 60;
$period_no = date('Ymd').str_pad(floor(($now%86400)/$secs),4,'0',STR_PAD_LEFT);
$rem = $secs - ($now % $secs);
include 'includes/header.php';
?>
<div class="wingo-header">
  <div style="display:flex;align-items:center;justify-content:space-between;">
    <a href="/index.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">K3 Lotre</div>
    <div style="font-size:14px;">🎲</div>
  </div>
</div>
<div class="wingo-tabs" style="padding:8px 12px 10px;">
  <button class="wingo-tab active">1 Min</button>
  <button class="wingo-tab">3 Min</button>
  <button class="wingo-tab">5 Min</button>
</div>

<div class="period-box">
  <div>
    <div class="period-label">Period</div>
    <div class="period-no"><?= $period_no ?></div>
    <div style="font-size:12px;color:var(--muted);margin-top:8px;">Count Down</div>
    <div id="countTimer" class="timer-val"><?= sprintf('%02d:%02d',floor($rem/60),$rem%60) ?></div>
  </div>
  <div class="dice-row" style="padding:0;">
    <div class="dice">🎲</div>
    <div class="dice">🎲</div>
    <div class="dice">🎲</div>
  </div>
</div>

<div class="section">
  <div class="section-title" style="margin-bottom:10px;">Bet Options</div>
  <div class="k3-bet-types">
    <div class="k3btn" onclick="openBetModal('k3_total','big','Big (11-17)','red')">
      <div class="k3btn-name">🔴 Big</div>
      <div class="k3btn-odds">Total 11-17 · 2x</div>
    </div>
    <div class="k3btn" onclick="openBetModal('k3_total','small','Small (3-10)','green')">
      <div class="k3btn-name">🟢 Small</div>
      <div class="k3btn-odds">Total 3-10 · 2x</div>
    </div>
    <div class="k3btn" onclick="openBetModal('k3_parity','odd','Odd','violet')">
      <div class="k3btn-name">🟣 Odd</div>
      <div class="k3btn-odds">Odd total · 2x</div>
    </div>
    <div class="k3btn" onclick="openBetModal('k3_parity','even','Even','green')">
      <div class="k3btn-name">🟢 Even</div>
      <div class="k3btn-odds">Even total · 2x</div>
    </div>
  </div>
  <div class="section-title" style="margin:12px 0 10px;">Bet on Total</div>
  <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px;">
    <?php for($t=3;$t<=17;$t++): ?>
    <div class="k3btn" style="padding:8px 4px;" onclick="openBetModal('k3_sum','<?= $t ?>','Sum <?= $t ?>','violet')">
      <div class="k3btn-name"><?= $t ?></div>
      <div class="k3btn-odds" style="font-size:10px;"><?= $t<=10?'S':'B' ?></div>
    </div>
    <?php endfor; ?>
  </div>
</div>

<!-- HISTORY -->
<div class="section">
  <div class="section-title" style="margin-bottom:10px;">K3 History</div>
  <div class="hist-table">
    <?php if(empty($results)):
      for($i=0;$i<8;$i++):
        $d1=rand(1,6);$d2=rand(1,6);$d3=rand(1,6);$tot=$d1+$d2+$d3;
    ?>
      <div class="hist-row">
        <div style="flex:1;font-size:11px;">202406<?= rand(10,28) ?>0<?= rand(1,9) ?></div>
        <div style="display:flex;gap:4px;"><?php foreach([$d1,$d2,$d3] as $d): ?><div style="width:24px;height:24px;background:var(--red);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;"><?= $d ?></div><?php endforeach; ?></div>
        <div style="font-size:12px;font-weight:700;margin-left:8px;"><?= $tot ?></div>
        <div style="font-size:12px;color:<?= $tot>=11?'var(--red)':'var(--green)' ?>;margin-left:6px;"><?= $tot>=11?'Big':'Small' ?></div>
      </div>
    <?php endfor;
    else: foreach($results as $r): ?>
      <div class="hist-row">
        <div style="flex:1;font-size:11px;"><?= $r['period_no'] ?></div>
        <div style="display:flex;gap:4px;">
          <?php foreach(['dice1','dice2','dice3'] as $dk): ?>
          <div style="width:24px;height:24px;background:var(--red);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;"><?= $r[$dk] ?></div>
          <?php endforeach; ?>
        </div>
        <div style="font-size:12px;font-weight:700;margin-left:8px;"><?= $r['total'] ?></div>
        <div style="font-size:12px;color:<?= $r['result_size']==='big'?'var(--red)':'var(--green)' ?>;margin-left:6px;"><?= ucfirst($r['result_size']??'') ?></div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<!-- BET MODAL -->
<div class="modal-overlay" id="betModal">
  <div class="modal-box">
    <div class="modal-head">
      <div class="modal-title">K3 Lotre · 1 Min</div>
      <div class="modal-close" onclick="closeModal('betModal')">✕</div>
    </div>
    <div class="modal-body">
      <div class="modal-sel">
        <div class="rball sel-ball green" id="selBall">🎲</div>
        <div><div class="sel-label" id="selLabel">Big</div><div style="font-size:11px;color:var(--muted);">Win 2x multiplier</div></div>
      </div>
      <div class="modal-label">Select Amount</div>
      <div class="amount-btns">
        <div class="amt-btn" data-val="10">₹10</div>
        <div class="amt-btn" data-val="50">₹50</div>
        <div class="amt-btn" data-val="100">₹100</div>
        <div class="amt-btn" data-val="500">₹500</div>
        <div class="amt-btn" data-val="1000">₹1K</div>
        <div class="amt-btn" data-val="x5">×5</div>
      </div>
      <input type="number" id="betAmountInp" class="amt-input" value="10" min="10" oninput="updateModalInfo()"/>
      <div class="modal-info">
        <div class="modal-info-row"><span>Amount</span><span id="infoAmt">₹10.00</span></div>
        <div class="modal-info-row"><span>Fee (2%)</span><span id="infoFee">₹0.20</span></div>
        <div class="modal-info-row"><span>After Fee</span><span id="infoAfter">₹9.80</span></div>
      </div>
      <div style="font-size:11px;color:var(--muted);margin-bottom:12px;">Balance: <span class="balance-val"><?= money($me['balance']) ?></span></div>
      <button class="modal-confirm" onclick="placeBet('k3')">✅ Confirm Bet</button>
    </div>
  </div>
</div>
<script>startTimer(<?= $rem ?>,'countTimer',()=>location.reload());</script>
<?php include 'includes/footer.php'; ?>
