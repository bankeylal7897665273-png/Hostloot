<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'Gift Card - 66Lottery';
$NAV_ACTIVE = 'activity';
$me = me(); $db = db_connect();
$msg=''; $msg_type='success';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $code = strtoupper(trim($_POST['code']??''));
    if (!$code) { $msg='Please enter a gift card code.'; $msg_type='error'; }
    else {
        $gc = $db->prepare("SELECT * FROM gift_cards WHERE code=? AND status='active' LIMIT 1");
        $gc->execute([$code]); $gc=$gc->fetch();
        if (!$gc) { $msg='❌ Invalid or already used gift card.'; $msg_type='error'; }
        else {
            $db->prepare("UPDATE gift_cards SET status='used',used_by=?,used_at=NOW() WHERE id=?")->execute([$_SESSION['uid'],$gc['id']]);
            $db->prepare("UPDATE users SET balance=balance+? WHERE id=?")->execute([$gc['amount'],$_SESSION['uid']]);
            $msg='🎉 Gift card redeemed! ₹'.number_format($gc['amount'],2).' added to your balance!';
            $me = me();
        }
    }
}
include 'includes/header.php';
?>
<div class="wingo-header">
  <div style="display:flex;align-items:center;gap:12px;">
    <a href="/activity.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">Gift Card</div>
  </div>
</div>

<!-- GIFT HERO -->
<div class="gift-hero">
  <div class="gift-icon">🎁</div>
  <div class="gift-title">Redeem Gift Card</div>
  <div class="gift-sub">Enter your gift card code to get instant bonus!</div>
</div>

<!-- BALANCE -->
<div style="margin:0 12px 12px;background:var(--card);border:1px solid var(--border);border-radius:12px;padding:14px;display:flex;justify-content:space-between;align-items:center;">
  <div><div style="font-size:11px;color:var(--muted);">Your Balance</div><div style="font-size:20px;font-weight:800;color:var(--green);"><?= money($me['balance']) ?></div></div>
  <div style="font-size:30px;">💰</div>
</div>

<?php if($msg): ?>
<div style="margin:0 12px 12px;padding:14px;border-radius:12px;font-size:14px;font-weight:600;background:rgba(<?= $msg_type==='error'?'240,83,43':'0,185,107' ?>,.12);border:1px solid rgba(<?= $msg_type==='error'?'240,83,43':'0,185,107' ?>,.3);color:<?= $msg_type==='error'?'var(--red)':'var(--green)' ?>;"><?= $msg ?></div>
<?php endif; ?>

<!-- INPUT -->
<div class="gift-input-wrap">
  <div style="font-size:13px;font-weight:700;margin-bottom:12px;">Enter Gift Card Code</div>
  <form method="POST">
    <input class="gift-inp" type="text" name="code" placeholder="XXXX-XXXX-XXXX" value="<?= clean($_POST['code']??'') ?>"/>
    <button type="submit" class="submit-btn">🎁 Redeem Now</button>
  </form>
</div>

<!-- HOW TO GET -->
<div class="section">
  <div class="section-title" style="margin-bottom:10px;">How to Get Gift Cards?</div>
  <div style="background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden;">
    <div style="display:flex;align-items:center;gap:12px;padding:14px;border-bottom:1px solid var(--border);">
      <div style="width:40px;height:40px;background:rgba(0,185,107,.15);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;">👥</div>
      <div><div style="font-size:13px;font-weight:700;">Refer Friends</div><div style="font-size:12px;color:var(--muted);margin-top:2px;">Earn gift cards when friends join</div></div>
    </div>
    <div style="display:flex;align-items:center;gap:12px;padding:14px;border-bottom:1px solid var(--border);">
      <div style="width:40px;height:40px;background:rgba(245,197,24,.15);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;">🏆</div>
      <div><div style="font-size:13px;font-weight:700;">Win Tournaments</div><div style="font-size:12px;color:var(--muted);margin-top:2px;">Top players get special gift cards</div></div>
    </div>
    <div style="display:flex;align-items:center;gap:12px;padding:14px;">
      <div style="width:40px;height:40px;background:rgba(122,82,201,.15);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;">📱</div>
      <div><div style="font-size:13px;font-weight:700;">Follow Social Media</div><div style="font-size:12px;color:var(--muted);margin-top:2px;">Giveaways on Telegram & Instagram</div></div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
