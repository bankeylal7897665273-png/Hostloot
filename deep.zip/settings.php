<?php
define('IN_APP', true);
require_once __DIR__ . '/config.php';
require_login();
$PAGE_TITLE = 'Settings - 66Lottery';
$NAV_ACTIVE = 'profile';
$me = me(); $db = db_connect();
$msg=''; $msg_type='success';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action = $_POST['action']??'';
    if ($action==='profile') {
        $uname = clean($_POST['username']??'');
        if ($uname) { $db->prepare("UPDATE users SET username=? WHERE id=?")->execute([$uname,$_SESSION['uid']]); $msg='✅ Username updated!'; }
    } elseif ($action==='password') {
        $old=$_POST['old_pass']??''; $new=$_POST['new_pass']??''; $con=$_POST['con_pass']??'';
        if (!password_verify($old,$me['password'])) { $msg='❌ Old password wrong.'; $msg_type='error'; }
        elseif (strlen($new)<6) { $msg='❌ Min 6 characters.'; $msg_type='error'; }
        elseif ($new!==$con) { $msg='❌ Passwords do not match.'; $msg_type='error'; }
        else { $db->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($new,PASSWORD_BCRYPT),$_SESSION['uid']]); $msg='✅ Password changed!'; }
    }
    $me = me();
}
include 'includes/header.php';
?>
<div class="wingo-header">
  <div style="display:flex;align-items:center;gap:12px;">
    <a href="/profile.php" style="color:#fff;font-size:20px;"><i class="fa fa-arrow-left"></i></a>
    <div style="font-size:17px;font-weight:800;">Settings</div>
  </div>
</div>
<?php if($msg): ?>
<div style="margin:12px;padding:12px;border-radius:10px;font-size:13px;background:rgba(<?= $msg_type==='error'?'240,83,43':'0,185,107'?>,.12);border:1px solid rgba(<?= $msg_type==='error'?'240,83,43':'0,185,107'?>,.3);color:<?= $msg_type==='error'?'var(--red)':'var(--green)'?>;"><?= $msg ?></div>
<?php endif; ?>
<div class="section">
  <div class="section-title" style="margin-bottom:12px;">Edit Profile</div>
  <div style="background:var(--card);border:1px solid var(--border);border-radius:12px;padding:16px;margin-bottom:16px;">
    <form method="POST">
      <input type="hidden" name="action" value="profile"/>
      <div class="form-group">
        <label class="form-label">👤 Username</label>
        <input class="form-input" type="text" name="username" value="<?= htmlspecialchars($me['username']??'') ?>" placeholder="Enter username"/>
      </div>
      <div class="form-group">
        <label class="form-label">📱 Mobile</label>
        <input class="form-input" value="<?= htmlspecialchars($me['mobile']??'') ?>" disabled style="opacity:.5;"/>
      </div>
      <button type="submit" class="submit-btn">Save Profile</button>
    </form>
  </div>
  <div class="section-title" style="margin-bottom:12px;">Change Password</div>
  <div style="background:var(--card);border:1px solid var(--border);border-radius:12px;padding:16px;">
    <form method="POST">
      <input type="hidden" name="action" value="password"/>
      <div class="form-group"><label class="form-label">🔒 Current Password</label><input class="form-input" type="password" name="old_pass" placeholder="Enter current password" required/></div>
      <div class="form-group"><label class="form-label">🔑 New Password</label><input class="form-input" type="password" name="new_pass" placeholder="Min 6 characters" required/></div>
      <div class="form-group"><label class="form-label">🔑 Confirm Password</label><input class="form-input" type="password" name="con_pass" placeholder="Repeat new password" required/></div>
      <button type="submit" class="submit-btn">Change Password</button>
    </form>
  </div>
</div>
<div class="section">
  <div class="menu-list">
    <div class="menu-item" onclick="toast('Coming soon!','error')"><div class="menu-icon" style="background:rgba(0,185,107,.15);">🌐</div><div class="menu-text"><div class="menu-name">Language</div><div class="menu-desc">English</div></div><div class="menu-arrow">›</div></div>
    <div class="menu-item" onclick="toast('Coming soon!','error')"><div class="menu-icon" style="background:rgba(245,197,24,.15);">🔔</div><div class="menu-text"><div class="menu-name">Notifications</div><div class="menu-desc">Manage alerts</div></div><div class="menu-arrow">›</div></div>
    <a href="/logout.php" class="menu-item"><div class="menu-icon" style="background:rgba(240,83,43,.1);">🚪</div><div class="menu-text"><div class="menu-name" style="color:var(--red);">Logout</div></div><div class="menu-arrow">›</div></a>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
