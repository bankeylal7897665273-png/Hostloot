// ============================================================
//  66LOTTERY – app.js
// ============================================================

// Dropdown toggle
function toggleDropdown() {
  document.getElementById('userDropdown')?.classList.toggle('open');
}
document.addEventListener('click', e => {
  const dd = document.getElementById('userDropdown');
  if (dd && !e.target.closest('.topnav__avatar') && !e.target.closest('#userDropdown')) {
    dd.classList.remove('open');
  }
});

// ============================================================
//  COUNTDOWN TIMER (for game pages)
// ============================================================
function startCountdown(targetSeconds, displayId, onComplete) {
  let s = targetSeconds;
  const el = document.getElementById(displayId);
  if (!el) return;
  const tick = () => {
    const m = String(Math.floor(s / 60)).padStart(2, '0');
    const sec = String(s % 60).padStart(2, '0');
    el.textContent = m + ':' + sec;
    if (s <= 0) { if (onComplete) onComplete(); return; }
    s--;
    setTimeout(tick, 1000);
  };
  tick();
}

// ============================================================
//  BET OPTION SELECTION
// ============================================================
document.addEventListener('click', e => {
  const opt = e.target.closest('.bet-option');
  if (opt) {
    const group = opt.closest('.bet-options');
    if (group) group.querySelectorAll('.bet-option').forEach(o => o.classList.remove('selected'));
    opt.classList.add('selected');
    // Store selection
    const val = opt.dataset.value;
    const hiddenInput = document.getElementById('betSelection');
    if (hiddenInput) hiddenInput.value = val;
  }
});

// Quick bet amounts
document.addEventListener('click', e => {
  const qb = e.target.closest('.quick-bet');
  if (qb) {
    const input = document.getElementById('betAmount');
    if (input) input.value = qb.dataset.amount;
  }
});

// ============================================================
//  PLACE BET (AJAX)
// ============================================================
function placeBet(gameSlug) {
  const selection = document.getElementById('betSelection')?.value;
  const amount    = document.getElementById('betAmount')?.value;
  const resultEl  = document.getElementById('betResult');

  if (!selection) { showAlert('Please select a bet option.', 'error'); return; }
  if (!amount || amount < 10) { showAlert('Minimum bet is ₹10.', 'error'); return; }

  fetch('api/place_bet.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ game: gameSlug, selection, amount })
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      showAlert('Bet placed! ₹' + amount + ' on ' + selection, 'success');
      // Update balance chip
      const chip = document.querySelector('.balance-chip span');
      if (chip && data.new_balance) chip.textContent = '₹' + parseFloat(data.new_balance).toFixed(2);
    } else {
      showAlert(data.error || 'Failed to place bet.', 'error');
    }
  })
  .catch(() => showAlert('Network error. Try again.', 'error'));
}

// ============================================================
//  ALERT TOAST
// ============================================================
function showAlert(msg, type = 'info') {
  const colors = { success: '#00e676', error: '#ff1744', info: '#7c3aed' };
  const toast = document.createElement('div');
  toast.style.cssText = `
    position:fixed; bottom:80px; left:50%; transform:translateX(-50%);
    background:#11111f; border:1px solid ${colors[type]};
    color:${colors[type]}; padding:12px 24px; border-radius:99px;
    font-size:13px; font-weight:600; z-index:9999;
    box-shadow:0 4px 20px rgba(0,0,0,.4);
    animation: fadeInUp .3s ease;
  `;
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// ============================================================
//  WIN GO TIMER (auto-cycle every 1 min)
// ============================================================
(function initWingoTimer() {
  const el = document.getElementById('wingoTimer');
  if (!el) return;
  const now = new Date();
  const elapsed = now.getSeconds() + (now.getMinutes() % 1) * 60;
  const remaining = 60 - (now.getSeconds());
  startCountdown(remaining, 'wingoTimer', () => {
    // Reload results after each round
    loadLatestResults();
    initWingoTimer();
  });
})();

function loadLatestResults() {
  fetch('api/latest_results.php')
    .then(r => r.json())
    .then(data => {
      const container = document.getElementById('recentResults');
      if (!container || !data.results) return;
      container.innerHTML = data.results.map(r => {
        const cls = r.color === 'red' ? 'ball-red' : r.color === 'green' ? 'ball-green' : 'ball-violet';
        return `<div class="result-ball ${cls}">${r.result}</div>`;
      }).join('');
    }).catch(() => {});
}

// Load on page ready
if (document.getElementById('recentResults')) loadLatestResults();
